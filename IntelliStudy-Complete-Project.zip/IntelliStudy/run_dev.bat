@echo off
title IntelliStudy - Development Mode
echo ================================================================
echo         IntelliStudy - Starting Development Servers
echo ================================================================
echo Starting FastAPI Backend (Port 8000) and Vite Frontend (Port 3000)...
echo.

set "PATH=%LOCALAPPDATA%\node-portable;%PATH%"

start "IntelliStudy Backend" cmd /k "cd /d "%~dp0backend" && python main.py"
start "IntelliStudy Frontend" cmd /k "cd /d "%~dp0frontend" && npm run dev"

timeout /t 3 >nul
start http://localhost:3000
echo Development servers running!
