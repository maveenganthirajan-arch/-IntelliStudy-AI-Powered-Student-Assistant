@echo off
title IntelliStudy - AI-Powered Student Assistant
echo ================================================================
echo         IntelliStudy - AI-Powered Student Assistant
echo ================================================================
echo Starting backend server on http://127.0.0.1:8000 ...
echo Press Ctrl+C anytime to stop.
echo.

cd /d "%~dp0backend"
start http://127.0.0.1:8000
python main.py
pause
