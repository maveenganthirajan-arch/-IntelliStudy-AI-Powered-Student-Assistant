import axios from 'axios';
import { 
  DashboardData, 
  TimetableEvent, 
  Note, 
  Quiz, 
  QuizSubmitResult, 
  FlashcardDeck, 
  ChatMessage, 
  SettingsData 
} from '../types';

const api = axios.create({
  baseURL: '/api',
});

// Analytics & Dashboard
export const getDashboard = async (): Promise<DashboardData> => {
  const res = await api.get('/analytics/dashboard');
  return res.data;
};

export const updateLessonProgress = async (lessonId: number, progress: number) => {
  const res = await api.post(`/analytics/update-lesson-progress/${lessonId}?progress=${progress}`);
  return res.data;
};

// Timetable
export const getTimetable = async (day?: number): Promise<TimetableEvent[]> => {
  const res = await api.get('/timetable', { params: day !== undefined ? { day } : {} });
  return res.data;
};

export const createTimetableEvent = async (data: Partial<TimetableEvent>): Promise<TimetableEvent> => {
  const res = await api.post('/timetable', data);
  return res.data;
};

export const toggleTimetableComplete = async (eventId: number): Promise<TimetableEvent> => {
  const res = await api.put(`/timetable/${eventId}/toggle-complete`);
  return res.data;
};

export const deleteTimetableEvent = async (eventId: number) => {
  const res = await api.delete(`/timetable/${eventId}`);
  return res.data;
};

export const generateAITimetable = async (
  topics: string[], 
  dailyHours: number = 3.0, 
  startDay: number = 1,
  goals?: string
): Promise<TimetableEvent[]> => {
  const res = await api.post('/timetable/ai-generate', {
    topics,
    daily_hours: dailyHours,
    start_day: startDay,
    goals,
  });
  return res.data;
};

// Notes & Summaries
export const getNotes = async (): Promise<Note[]> => {
  const res = await api.get('/notes');
  return res.data;
};

export const getNote = async (noteId: number): Promise<Note> => {
  const res = await api.get(`/notes/${noteId}`);
  return res.data;
};

export const uploadNote = async (file?: File, title?: string, textContent?: string): Promise<Note> => {
  const formData = new FormData();
  if (file) formData.append('file', file);
  if (title) formData.append('title', title);
  if (textContent) formData.append('text_content', textContent);

  const res = await api.post('/notes/upload', formData, {
    headers: { 'Content-Type': 'multipart/form-data' },
  });
  return res.data;
};

export const deleteNote = async (noteId: number) => {
  const res = await api.delete(`/notes/${noteId}`);
  return res.data;
};

// Quizzes
export const getQuizzes = async (): Promise<Quiz[]> => {
  const res = await api.get('/quizzes');
  return res.data;
};

export const getQuiz = async (quizId: number): Promise<Quiz> => {
  const res = await api.get(`/quizzes/${quizId}`);
  return res.data;
};

export const generateQuiz = async (
  topic: string, 
  noteId?: number, 
  numQuestions: number = 5,
  content?: string
): Promise<Quiz> => {
  const res = await api.post('/quizzes/generate', {
    topic,
    note_id: noteId,
    num_questions: numQuestions,
    content,
  });
  return res.data;
};

export const submitQuiz = async (quizId: number, answers: number[]): Promise<QuizSubmitResult> => {
  const res = await api.post(`/quizzes/${quizId}/submit`, {
    quiz_id: quizId,
    answers,
  });
  return res.data;
};

export const deleteQuiz = async (quizId: number) => {
  const res = await api.delete(`/quizzes/${quizId}`);
  return res.data;
};

// Flashcards
export const getFlashcardDecks = async (): Promise<FlashcardDeck[]> => {
  const res = await api.get('/flashcards');
  return res.data;
};

export const getFlashcardDeck = async (deckId: number): Promise<FlashcardDeck> => {
  const res = await api.get(`/flashcards/${deckId}`);
  return res.data;
};

export const generateFlashcards = async (
  topic: string, 
  noteId?: number, 
  numCards: number = 6,
  content?: string
): Promise<FlashcardDeck> => {
  const res = await api.post('/flashcards/generate', {
    topic,
    note_id: noteId,
    num_cards: numCards,
    content,
  });
  return res.data;
};

export const deleteFlashcardDeck = async (deckId: number) => {
  const res = await api.delete(`/flashcards/${deckId}`);
  return res.data;
};

// AI Assistant
export const sendChatMessage = async (message: string, context?: string): Promise<{ response: string; suggested_actions: string[] }> => {
  const res = await api.post('/assistant/chat', { message, context });
  return res.data;
};

export const getChatHistory = async (): Promise<ChatMessage[]> => {
  const res = await api.get('/assistant/history');
  return res.data;
};

// Settings
export const getSettings = async (): Promise<SettingsData> => {
  const res = await api.get('/settings');
  return res.data;
};

export const updateSettings = async (data: { gemini_api_key?: string; gemini_model?: string }) => {
  const res = await api.post('/settings', data);
  return res.data;
};

export default api;
