import React, { useState } from 'react';
import { Search, Bell, Plus, X, BookOpen, Brain, Calendar } from 'lucide-react';
import { UserProfile } from '../types';

interface HeaderProps {
  title: string;
  user?: UserProfile;
  onOpenQuickCreate: (type: 'note' | 'quiz' | 'event') => void;
  onSearch: (query: string) => void;
}

export const Header: React.FC<HeaderProps> = ({
  title,
  user,
  onOpenQuickCreate,
  onSearch,
}) => {
  const [showNotifications, setShowNotifications] = useState(false);
  const [showCreateMenu, setShowCreateMenu] = useState(false);
  const [searchVal, setSearchVal] = useState('');

  const notifications = [
    { id: 1, title: 'Upcoming Lecture in 30 mins', desc: 'How Machine Learning Works at 12:00', time: '10m ago' },
    { id: 2, title: 'Quiz Completed!', desc: 'Scored 100% in Neural Networks (+75 pts)', time: '1h ago' },
    { id: 3, title: 'Weekly Goal on Track', desc: 'You completed 62 out of 105 lessons', time: '3h ago' },
    { id: 4, title: 'AI Assistant Tip', desc: 'Review flashcards before your afternoon session', time: '5h ago' },
    { id: 5, title: 'Timetable Updated', desc: 'AI scheduled your Friday lab session', time: 'Yesterday' },
  ];

  return (
    <header className="h-16 px-6 lg:px-8 flex items-center justify-between border-b border-[#221c45]/70 bg-[#0e0c1f] sticky top-0 z-30">
      {/* Page Title */}
      <div className="flex items-center">
        <h1 className="text-2xl font-bold tracking-tight text-white capitalize">
          {title}
        </h1>
      </div>

      {/* Right Controls: Search, Notifications, Profile */}
      <div className="flex items-center gap-4 lg:gap-5">
        {/* Search Bar matching reference image */}
        <div className="relative hidden sm:block w-64 lg:w-72">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
          <input
            type="text"
            value={searchVal}
            onChange={(e) => {
              setSearchVal(e.target.value);
              onSearch(e.target.value);
            }}
            placeholder="Start searching here..."
            className="w-full bg-[#181432] text-xs text-gray-200 placeholder-gray-500 rounded-full pl-10 pr-4 py-2 border border-[#2b2354] focus:outline-none focus:border-purple-500 transition-all"
          />
        </div>

        {/* Notification Bell matching reference image */}
        <div className="relative">
          <button
            onClick={() => setShowNotifications(!showNotifications)}
            className="w-9 h-9 rounded-full bg-[#1e193c] border border-[#2e2658] flex items-center justify-center text-gray-300 hover:text-white hover:border-purple-400 transition-all relative"
            title="Notifications"
          >
            <Bell className="w-4 h-4" />
            <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#7c3aed] text-white text-[9px] font-bold rounded-full flex items-center justify-center border-2 border-[#0e0c1f]">
              5
            </span>
          </button>

          {/* Notifications Dropdown */}
          {showNotifications && (
            <div className="absolute right-0 mt-3 w-80 bg-[#161232] border border-[#322765] rounded-2xl shadow-2xl p-4 z-50">
              <div className="flex items-center justify-between pb-3 border-b border-[#2b2255]">
                <div className="flex items-center gap-2">
                  <h3 className="font-semibold text-white text-xs">Notifications</h3>
                  <span className="bg-purple-900/60 text-purple-300 text-[10px] px-2 py-0.5 rounded-full border border-purple-500/30">
                    5 new
                  </span>
                </div>
                <button
                  onClick={() => setShowNotifications(false)}
                  className="text-gray-400 hover:text-white text-xs"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>

              <div className="divide-y divide-[#251d4d] max-h-64 overflow-y-auto mt-2">
                {notifications.map((n) => (
                  <div key={n.id} className="py-2 px-1 hover:bg-[#201a45] rounded-lg transition-colors cursor-pointer">
                    <div className="flex items-start justify-between">
                      <p className="text-[11px] font-semibold text-gray-200">{n.title}</p>
                      <span className="text-[9px] text-gray-400">{n.time}</span>
                    </div>
                    <p className="text-[10px] text-gray-400 mt-0.5">{n.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* User Profile matching reference image */}
        <div className="flex items-center gap-3">
          <div className="text-right hidden sm:block leading-tight">
            <p className="text-xs font-bold text-white tracking-wide">
              {user?.name || 'Anastasiia H.'}
            </p>
            <p className="text-[10px] text-gray-400 font-medium">
              {user?.course || 'AI Course'}
            </p>
          </div>

          <div className="w-9 h-9 rounded-full overflow-hidden ring-1 ring-purple-400/40 bg-amber-400 flex items-center justify-center flex-shrink-0 shadow-sm">
            <img
              src="/user_avatar.png"
              alt="Anastasiia H."
              className="w-full h-full object-cover"
              onError={(e) => {
                (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=100&h=100&fit=crop&crop=face';
              }}
            />
          </div>

          {/* Plus Add Button matching reference image */}
          <div className="relative">
            <button
              onClick={() => setShowCreateMenu(!showCreateMenu)}
              className="w-8 h-8 rounded-full bg-[#1e193c] hover:bg-[#7c3aed] text-gray-300 hover:text-white border border-[#2f275c] flex items-center justify-center transition-all duration-200"
              title="Quick Add Action"
            >
              <Plus className="w-4 h-4" />
            </button>

            {showCreateMenu && (
              <div className="absolute right-0 mt-3 w-52 bg-[#171336] border border-[#372b72] rounded-xl shadow-2xl p-2 z-50">
                <button
                  onClick={() => {
                    setShowCreateMenu(false);
                    onOpenQuickCreate('note');
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-gray-200 hover:bg-[#261f56] rounded-lg transition-colors text-left"
                >
                  <BookOpen className="w-4 h-4 text-purple-400" />
                  <span>Upload & Summarize Note</span>
                </button>
                <button
                  onClick={() => {
                    setShowCreateMenu(false);
                    onOpenQuickCreate('quiz');
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-gray-200 hover:bg-[#261f56] rounded-lg transition-colors text-left"
                >
                  <Brain className="w-4 h-4 text-indigo-400" />
                  <span>Generate AI Quiz / Cards</span>
                </button>
                <button
                  onClick={() => {
                    setShowCreateMenu(false);
                    onOpenQuickCreate('event');
                  }}
                  className="w-full flex items-center gap-2.5 px-3 py-2 text-xs text-gray-200 hover:bg-[#261f56] rounded-lg transition-colors text-left"
                >
                  <Calendar className="w-4 h-4 text-emerald-400" />
                  <span>Add Study Session</span>
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
