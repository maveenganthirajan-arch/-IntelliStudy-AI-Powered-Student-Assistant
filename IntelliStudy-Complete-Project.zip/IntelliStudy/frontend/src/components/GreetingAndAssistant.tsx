import React, { useState } from 'react';
import { Maximize2, Mic, MicOff, Send, X, Bot, User as UserIcon } from 'lucide-react';
import { UserProfile, ChatMessage } from '../types';
import { sendChatMessage } from '../services/api';

interface GreetingAndAssistantProps {
  user?: UserProfile;
  onNavigateTab: (tab: string) => void;
}

export const GreetingAndAssistant: React.FC<GreetingAndAssistantProps> = ({
  user,
  onNavigateTab,
}) => {
  const [inputVal, setInputVal] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      sender: 'assistant',
      message: "Hi Anastasiia! I'm your IntelliStudy AI tutor. Ask me anything about machine learning, notes, or your upcoming lecture!",
    },
  ]);
  const [isTyping, setIsTyping] = useState(false);
  const [isListening, setIsListening] = useState(false);
  const [showFullChat, setShowFullChat] = useState(false);

  const tips = [
    { label: 'Tip', prompt: 'Summarize my Machine Learning notes with key formulas' },
    { label: 'Tip', prompt: 'Quiz me on backpropagation and activation functions' },
    { label: 'Tip', prompt: 'Give me an exam active recall tip' },
  ];

  const handleSend = async (textToSend?: string) => {
    const query = (textToSend || inputVal).trim();
    if (!query) return;

    const newMsgs: ChatMessage[] = [...messages, { sender: 'user', message: query }];
    setMessages(newMsgs);
    setInputVal('');
    setIsTyping(true);

    try {
      const data = await sendChatMessage(query);
      setMessages([
        ...newMsgs,
        { sender: 'assistant', message: data.response },
      ]);
    } catch (err) {
      setMessages([
        ...newMsgs,
        {
          sender: 'assistant',
          message:
            "I'm here to help! In neural networks, remember that backpropagation applies the multivariate chain rule across layers. Check out the Quizzes tab to practice!",
        },
      ]);
    } finally {
      setIsTyping(false);
    }
  };

  const toggleVoice = () => {
    if (!isListening) {
      setIsListening(true);
      setTimeout(() => {
        setInputVal("Explain how Gradient Descent minimizes loss");
        setIsListening(false);
      }, 2000);
    } else {
      setIsListening(false);
    }
  };

  return (
    <div className="flex flex-col h-full space-y-4 justify-between">
      {/* 1. Greeting Card matching reference image */}
      <div className="bg-[#181434] rounded-[28px] p-5 lg:p-6 border border-[#271f4f]/80 shadow-xl relative overflow-hidden flex items-center justify-between min-h-[145px]">
        <div className="z-10 max-w-[62%]">
          <h2 className="text-xl font-black text-white tracking-tight leading-tight">
            Hi, {user?.name?.split(' ')[0] || 'Anastasiia'}!
          </h2>
          <p className="text-xs text-gray-400 font-medium mt-1 leading-snug">
            Ready to make progress today?
          </p>
        </div>

        {/* 3D Memoji character image matching reference image */}
        <div className="w-24 h-28 flex items-end justify-center pointer-events-none flex-shrink-0">
          <img
            src="/mascot_avatar.png"
            alt="Anastasiia 3D Memoji"
            className="w-full h-full object-contain filter drop-shadow-md"
            onError={(e) => {
              (e.target as HTMLImageElement).src = 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&h=150&fit=crop';
            }}
          />
        </div>
      </div>

      {/* 2. AI Assistant Widget matching reference image */}
      <div className="bg-[#181434] rounded-[28px] p-5 lg:p-6 border border-[#271f4f]/80 shadow-xl flex-1 flex flex-col justify-between">
        {/* Header: AI Assistant + Expand Icon */}
        <div className="flex items-center justify-between mb-1">
          <h2 className="text-lg font-bold text-white tracking-wide">
            AI Assistant
          </h2>
          <button
            onClick={() => setShowFullChat(true)}
            className="text-gray-400 hover:text-white transition-colors p-1"
            title="Expand Full Chat"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Center: Glowing 3D Floating Orb */}
        <div className="relative flex flex-col items-center justify-center my-auto py-3">
          {/* Ambient Glow */}
          <div className="absolute w-28 h-28 bg-purple-600/30 rounded-full blur-xl pointer-events-none animate-pulse"></div>

          {/* 3D Orb Graphic */}
          <div
            className="relative z-10 w-20 h-20 flex items-center justify-center animate-orb-float cursor-pointer hover:scale-105 transition-transform"
            onClick={() => handleSend("Explain key concepts of machine learning")}
            title="Click to ask AI Assistant"
          >
            <img
              src="/ai_orb.png"
              alt="Glowing AI Orb"
              className="w-full h-full object-contain filter drop-shadow-glow-neon"
            />
          </div>
        </div>

        {/* Quick Suggestion Pills matching reference image ("Tip", "Tip", "Tip") */}
        <div className="grid grid-cols-3 gap-2 mb-3">
          {tips.map((t, idx) => (
            <button
              key={idx}
              onClick={() => handleSend(t.prompt)}
              className="py-1.5 px-2 bg-[#211a43] hover:bg-[#2b2257] text-gray-300 hover:text-white text-xs font-semibold rounded-full border border-[#30275e] transition-all text-center truncate shadow-sm"
              title={t.prompt}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* Bottom Input Field with Mic and Send Button matching reference image */}
        <form
          onSubmit={(e) => {
            e.preventDefault();
            handleSend();
          }}
          className="relative flex items-center bg-[#1e193e] border border-[#2e265b] focus-within:border-purple-500 rounded-full pl-2.5 pr-2 py-1 transition-all"
        >
          {/* Mic Button */}
          <button
            type="button"
            onClick={toggleVoice}
            className={`p-1.5 rounded-full transition-colors ${
              isListening ? 'text-red-400 animate-pulse' : 'text-gray-400 hover:text-purple-300'
            }`}
            title={isListening ? 'Listening...' : 'Voice Input'}
          >
            {isListening ? <MicOff className="w-3.5 h-3.5" /> : <Mic className="w-3.5 h-3.5" />}
          </button>

          {/* Input text field */}
          <input
            type="text"
            value={inputVal}
            onChange={(e) => setInputVal(e.target.value)}
            placeholder={isListening ? "Listening..." : "Ask me about..."}
            className="flex-1 bg-transparent text-xs text-white placeholder-gray-500 px-2 focus:outline-none"
          />

          {/* Send Arrow Button */}
          <button
            type="submit"
            disabled={!inputVal.trim() && !isListening}
            className={`w-7 h-7 rounded-full flex items-center justify-center transition-all ${
              inputVal.trim()
                ? 'bg-[#7c3aed] text-white shadow-glow-purple hover:scale-105 active:scale-95'
                : 'bg-[#292252] text-gray-500 cursor-not-allowed'
            }`}
          >
            <Send className="w-3 h-3" />
          </button>
        </form>
      </div>

      {/* Expanded Interactive AI Chat Modal */}
      {showFullChat && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#14102e] border border-purple-500/30 rounded-3xl w-full max-w-2xl h-[580px] flex flex-col shadow-2xl overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            {/* Modal Header */}
            <div className="p-4 border-b border-[#251d52] flex items-center justify-between bg-[#19143a]">
              <div className="flex items-center gap-3">
                <div className="w-9 h-9 rounded-full bg-purple-900/60 border border-purple-400/40 flex items-center justify-center">
                  <Bot className="w-4 h-4 text-purple-300" />
                </div>
                <div>
                  <h3 className="text-xs font-bold text-white">IntelliStudy Assistant</h3>
                  <p className="text-[10px] text-emerald-400 flex items-center gap-1 font-medium">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                    Powered by Gemini AI
                  </p>
                </div>
              </div>
              <button
                onClick={() => setShowFullChat(false)}
                className="w-7 h-7 rounded-full bg-[#201a47] hover:bg-[#2b225d] text-gray-400 hover:text-white flex items-center justify-center transition-colors"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>

            {/* Chat Messages */}
            <div className="flex-1 overflow-y-auto p-4 space-y-3.5">
              {messages.map((m, idx) => (
                <div
                  key={idx}
                  className={`flex items-start gap-2.5 ${
                    m.sender === 'user' ? 'justify-end' : 'justify-start'
                  }`}
                >
                  {m.sender === 'assistant' && (
                    <div className="w-6 h-6 rounded-full bg-purple-900/60 border border-purple-400/30 flex items-center justify-center flex-shrink-0 mt-0.5">
                      <Bot className="w-3.5 h-3.5 text-purple-300" />
                    </div>
                  )}

                  <div
                    className={`max-w-[80%] rounded-2xl px-3.5 py-2.5 text-xs leading-relaxed ${
                      m.sender === 'user'
                        ? 'bg-[#7c3aed] text-white shadow-glow-purple font-medium'
                        : 'bg-[#1e1844] text-gray-200 border border-[#322765]'
                    }`}
                  >
                    <p className="whitespace-pre-line">{m.message}</p>
                  </div>

                  {m.sender === 'user' && (
                    <div className="w-6 h-6 rounded-full bg-[#322765] flex items-center justify-center flex-shrink-0 mt-0.5">
                      <UserIcon className="w-3.5 h-3.5 text-gray-300" />
                    </div>
                  )}
                </div>
              ))}

              {isTyping && (
                <div className="flex items-center gap-2 text-gray-400 text-xs pl-8">
                  <span className="w-1.5 h-1.5 rounded-full bg-purple-400 animate-ping"></span>
                  <span>AI Assistant is analyzing...</span>
                </div>
              )}
            </div>

            {/* Modal Input */}
            <div className="p-3.5 border-t border-[#251d52] bg-[#19143a]">
              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleSend();
                }}
                className="flex items-center gap-2"
              >
                <input
                  type="text"
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  placeholder="Ask a question or request a study summary..."
                  className="flex-1 bg-[#120e29] border border-[#2f255e] rounded-full px-4 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                />
                <button
                  type="submit"
                  disabled={!inputVal.trim()}
                  className="bg-[#7c3aed] hover:bg-[#6d28d9] disabled:opacity-50 text-white font-semibold px-4 py-2 rounded-full text-xs transition-all shadow-glow-purple flex items-center gap-1"
                >
                  <Send className="w-3 h-3" />
                  <span>Send</span>
                </button>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
