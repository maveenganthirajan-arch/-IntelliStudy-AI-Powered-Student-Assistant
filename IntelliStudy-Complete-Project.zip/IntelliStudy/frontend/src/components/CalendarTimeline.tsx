import React, { useState } from 'react';
import { Maximize2, Clock } from 'lucide-react';
import { TimetableEvent } from '../types';

interface CalendarTimelineProps {
  events: TimetableEvent[];
  onJoinSession: (event: TimetableEvent) => void;
  onToggleComplete: (eventId: number) => void;
}

export const CalendarTimeline: React.FC<CalendarTimelineProps> = ({
  events,
  onJoinSession,
  onToggleComplete,
}) => {
  const [selectedDay, setSelectedDay] = useState<number>(2); // 2 = Tuesday (Tu 06 in image)
  const [activeModalEvent, setActiveModalEvent] = useState<TimetableEvent | null>(null);

  const days = [
    { label: 'Su', date: '04', dayIndex: 0 },
    { label: 'Mo', date: '05', dayIndex: 1 },
    { label: 'Tu', date: '06', dayIndex: 2 },
    { label: 'We', date: '07', dayIndex: 3 },
    { label: 'Th', date: '08', dayIndex: 4 },
    { label: 'Fr', date: '09', dayIndex: 5 },
  ];

  const filteredEvents = events.filter((e) => e.day_index === selectedDay);

  // Time marks matching reference image: 12:00, 13:00, 14:00, 15:00, 16:00, 17:00
  const hours = ['12:00', '13:00', '14:00', '15:00', '16:00', '17:00'];

  // Event 1 (12:00 - 13:45) and Event 2 (16:00 - 17:45)
  const event1 = filteredEvents.find((e) => e.start_time.startsWith('12')) || filteredEvents[0];
  const event2 = filteredEvents.find((e) => e.start_time.startsWith('16')) || filteredEvents[1];

  return (
    <div className="bg-[#181434] rounded-[28px] p-5 lg:p-6 flex flex-col h-full border border-[#271f4f]/80 shadow-xl justify-between">
      {/* Top Header: Calendar (2) + Expand Icon */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-lg font-bold text-white tracking-wide">
            Calendar ({filteredEvents.length})
          </h2>
          <button
            onClick={() => setActiveModalEvent(filteredEvents[0] || null)}
            className="text-gray-400 hover:text-white transition-colors p-1"
            title="Expand View"
          >
            <Maximize2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Horizontal Day Selector matching reference image */}
        <div className="grid grid-cols-6 gap-2 mb-6">
          {days.map((d) => {
            const isSelected = selectedDay === d.dayIndex;
            return (
              <button
                key={d.label}
                onClick={() => setSelectedDay(d.dayIndex)}
                className={`flex flex-col items-center justify-center py-2 rounded-2xl transition-all duration-200 ${
                  isSelected
                    ? 'bg-white text-[#0e0c1f] shadow-md font-bold'
                    : 'bg-[#1e193e]/60 text-gray-400 hover:bg-[#251f4d] hover:text-white'
                }`}
              >
                <span className="text-[10px] font-medium leading-none">{d.label}</span>
                <span className="text-xs font-extrabold mt-1 leading-none">{d.date}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Timeline Container with exact hour marks and positioned cards */}
      <div className="relative flex-1 min-h-[420px] flex flex-col justify-between py-1">
        {/* Subtle Horizontal Grid lines at each hour */}
        {hours.map((h, i) => (
          <div key={h} className="relative flex items-center h-8">
            <span className="w-12 text-[11px] font-medium text-gray-400 select-none">
              {h}
            </span>
            <div className="flex-1 border-b border-[#251f4c]/60"></div>
          </div>
        ))}

        {/* Card 1: 12:00 – 13:45 */}
        {event1 && (
          <div className="absolute top-[18px] left-14 right-0 bg-[#211a43] border border-[#312760] rounded-2xl p-3.5 shadow-lg z-10 hover:border-purple-500/50 transition-all">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-semibold text-gray-300">
                | {event1.start_time} – {event1.end_time}
              </span>

              {/* Classmate Avatars */}
              <div className="flex items-center -space-x-1.5">
                <div className="w-5 h-5 rounded-full overflow-hidden border border-[#211a43]">
                  <img src="/user_avatar.png" alt="Attendee" className="w-full h-full object-cover" />
                </div>
                <div className="w-5 h-5 rounded-full overflow-hidden border border-[#211a43] bg-purple-900">
                  <img src="/mascot_avatar.png" alt="Attendee" className="w-full h-full object-cover" />
                </div>
                <div className="w-5 h-5 rounded-full border border-[#211a43] bg-amber-400 text-[8px] font-bold text-black flex items-center justify-center">
                  +1
                </div>
              </div>
            </div>

            <h3 className="text-xs font-semibold text-white leading-snug mb-3 pr-2">
              {event1.title}
            </h3>

            <div className="flex justify-end">
              <button
                onClick={() => onJoinSession(event1)}
                className="bg-white hover:bg-gray-100 text-[#0c0a1a] text-xs font-bold px-5 py-1.5 rounded-full shadow-sm hover:scale-105 active:scale-95 transition-all"
              >
                Join
              </button>
            </div>
          </div>
        )}

        {/* 15:30 Current Time Line Indicator matching reference image */}
        <div className="absolute top-[260px] left-8 right-0 flex items-center z-20 pointer-events-none">
          <span className="bg-[#7c3aed] text-white text-[10px] font-bold px-2 py-0.5 rounded-full shadow-sm mr-1">
            15:30
          </span>
          <div className="flex-1 h-px bg-purple-500/80"></div>
        </div>

        {/* Card 2: 16:00 – 17:45 */}
        {event2 && (
          <div className="absolute top-[305px] left-14 right-0 bg-[#211a43] border border-[#312760] rounded-2xl p-3.5 shadow-lg z-10 hover:border-purple-500/50 transition-all">
            <div className="flex items-center justify-between mb-1.5">
              <span className="text-[11px] font-semibold text-gray-300">
                | {event2.start_time} – {event2.end_time}
              </span>

              {/* Classmate Avatars */}
              <div className="flex items-center -space-x-1.5">
                <div className="w-5 h-5 rounded-full overflow-hidden border border-[#211a43]">
                  <img src="/user_avatar.png" alt="Attendee" className="w-full h-full object-cover" />
                </div>
                <div className="w-5 h-5 rounded-full overflow-hidden border border-[#211a43] bg-purple-900">
                  <img src="/mascot_avatar.png" alt="Attendee" className="w-full h-full object-cover" />
                </div>
                <div className="w-5 h-5 rounded-full border border-[#211a43] bg-amber-400 text-[8px] font-bold text-black flex items-center justify-center">
                  +2
                </div>
              </div>
            </div>

            <h3 className="text-xs font-semibold text-white leading-snug mb-3 pr-2">
              {event2.title}
            </h3>

            <div className="flex justify-end">
              <button
                onClick={() => onJoinSession(event2)}
                className="bg-white hover:bg-gray-100 text-[#0c0a1a] text-xs font-bold px-5 py-1.5 rounded-full shadow-sm hover:scale-105 active:scale-95 transition-all"
              >
                Join
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
