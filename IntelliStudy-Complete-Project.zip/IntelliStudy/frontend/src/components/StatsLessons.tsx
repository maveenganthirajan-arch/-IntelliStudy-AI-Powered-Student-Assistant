import React from 'react';
import { ArrowUp, ArrowDown } from 'lucide-react';
import { UserProfile, LessonProgress } from '../types';

interface StatsLessonsProps {
  user?: UserProfile;
  lastLessons: LessonProgress[];
  onContinueLesson: (lesson: LessonProgress) => void;
}

export const StatsLessons: React.FC<StatsLessonsProps> = ({
  user,
  lastLessons,
  onContinueLesson,
}) => {
  const points = user?.points ?? 836;
  const maxPoints = user?.max_points ?? 1500;
  const weeklyDelta = user?.points_weekly_delta ?? 290;
  const studyHours = (user?.study_hours ?? 8.4).toString().replace('.', ',');
  const completedLessons = user?.completed_lessons ?? 62;
  const totalLessons = user?.total_lessons ?? 105;
  const completionRate = user?.completion_rate_pct ?? 59;

  // SVG Circular progress
  const radius = 28;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (completionRate / 100) * circumference;

  return (
    <div className="flex flex-col h-full space-y-4 justify-between">
      {/* Top Row: Two Stats Cards side-by-side */}
      <div className="grid grid-cols-2 gap-3.5">
        {/* Card 1: Points & Hours */}
        <div className="bg-[#181434] rounded-[24px] p-4 border border-[#271f4f]/80 shadow-xl flex items-center justify-between">
          {/* Points */}
          <div className="flex-1 pr-2">
            <h3 className="text-base lg:text-lg font-black text-white tracking-tight leading-none">
              {points}/{maxPoints}
            </h3>
            <p className="text-[11px] text-gray-400 font-medium mt-1 leading-none">Points</p>
            <div className="flex items-center gap-0.5 text-[9px] font-bold text-emerald-400 mt-2 whitespace-nowrap">
              <ArrowUp className="w-3 h-3 text-emerald-400" />
              <span>{weeklyDelta} this week</span>
            </div>
          </div>

          {/* Divider */}
          <div className="w-px h-10 bg-[#2b2255] mx-1"></div>

          {/* Hours */}
          <div className="flex-1 pl-2">
            <h3 className="text-base lg:text-lg font-black text-white tracking-tight leading-none">
              {studyHours}
            </h3>
            <p className="text-[11px] text-gray-400 font-medium mt-1 leading-none">Hours</p>
            <div className="flex items-center gap-0.5 text-[9px] font-bold text-rose-400 mt-2 whitespace-nowrap">
              <ArrowDown className="w-3 h-3 text-rose-400" />
              <span>94% from last week</span>
            </div>
          </div>
        </div>

        {/* Card 2: Lessons & Circular Ring */}
        <div className="bg-[#181434] rounded-[24px] p-4 border border-[#271f4f]/80 shadow-xl flex items-center justify-between">
          <div>
            <h3 className="text-base lg:text-lg font-black text-white tracking-tight leading-none">
              {completedLessons}/{totalLessons}
            </h3>
            <p className="text-[11px] text-gray-400 font-medium mt-1 leading-none">Lessons</p>
          </div>

          {/* Circular SVG Ring */}
          <div className="relative w-16 h-16 flex items-center justify-center flex-shrink-0">
            <svg className="w-16 h-16 transform -rotate-90">
              <circle
                cx="32"
                cy="32"
                r={radius}
                className="stroke-[#241c47]"
                strokeWidth="5.5"
                fill="transparent"
              />
              <circle
                cx="32"
                cy="32"
                r={radius}
                stroke="#c084fc"
                strokeWidth="5.5"
                strokeDasharray={circumference}
                strokeDashoffset={strokeDashoffset}
                strokeLinecap="round"
                fill="transparent"
                className="transition-all duration-700 ease-out"
              />
            </svg>
            <span className="absolute text-xs font-black text-white">
              {completionRate}%
            </span>
          </div>
        </div>
      </div>

      {/* "Last lesson" Card */}
      <div className="bg-[#181434] rounded-[28px] p-5 lg:p-6 border border-[#271f4f]/80 shadow-xl flex-1 flex flex-col justify-between">
        <h2 className="text-lg font-bold text-white mb-3 tracking-wide">
          Last lesson
        </h2>

        <div className="space-y-3.5 flex-1 flex flex-col justify-around">
          {lastLessons.slice(0, 2).map((lesson) => (
            <div
              key={lesson.id}
              className="bg-[#211a43] border border-[#312760] hover:border-purple-500/50 rounded-2xl p-4 transition-all shadow-md"
            >
              <h3 className="text-xs font-semibold text-white mb-2 leading-tight">
                {lesson.title}
              </h3>

              {/* Avatar + Subtitle Speech Bubble */}
              <div className="flex items-center gap-2 mb-2">
                <div className="w-5 h-5 rounded-full overflow-hidden bg-purple-900 border border-purple-400/40 flex-shrink-0">
                  <img src="/mascot_avatar.png" alt="Coach" className="w-full h-full object-cover" />
                </div>
                <span className="text-[11px] text-purple-200/90 font-medium">
                  {lesson.subtitle}
                </span>
              </div>

              {/* Progress Bar + Percentage badge */}
              <div className="flex items-center gap-2 my-2">
                <div className="flex-1 h-1.5 bg-[#140f2b] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-indigo-300 rounded-full"
                    style={{ width: `${lesson.progress_pct}%` }}
                  ></div>
                </div>
                <span className="text-[9px] font-extrabold text-white bg-purple-600 px-1.5 py-0.5 rounded-full">
                  {lesson.progress_pct}%
                </span>
              </div>

              {/* Bottom Row: Timestamp + Continue Button */}
              <div className="flex items-center justify-between pt-1">
                <span className="text-[11px] text-gray-400 font-medium">
                  {lesson.last_accessed}
                </span>
                <button
                  onClick={() => onContinueLesson(lesson)}
                  className="bg-white hover:bg-gray-100 text-[#0c0a1a] text-xs font-bold px-5 py-1.5 rounded-full shadow-sm hover:scale-105 active:scale-95 transition-all"
                >
                  Continue
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
