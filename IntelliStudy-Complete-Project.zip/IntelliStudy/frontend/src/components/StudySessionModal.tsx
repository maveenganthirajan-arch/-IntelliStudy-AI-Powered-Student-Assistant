import React, { useState, useEffect } from 'react';
import { X, Play, Pause, RotateCcw, CheckCircle2, Sparkles, BookOpen, Clock } from 'lucide-react';
import confetti from 'canvas-confetti';
import { TimetableEvent, LessonProgress } from '../types';

interface StudySessionModalProps {
  event?: TimetableEvent | null;
  lesson?: LessonProgress | null;
  onClose: () => void;
  onSessionComplete: (pointsEarned: number, hoursAdded: number) => void;
}

export const StudySessionModal: React.FC<StudySessionModalProps> = ({
  event,
  lesson,
  onClose,
  onSessionComplete,
}) => {
  const [seconds, setSeconds] = useState(1500); // 25 min default Pomodoro
  const [isActive, setIsActive] = useState(false);
  const [completed, setCompleted] = useState(false);

  useEffect(() => {
    let interval: any = null;
    if (isActive && seconds > 0) {
      interval = setInterval(() => {
        setSeconds((prev) => prev - 1);
      }, 1000);
    } else if (seconds === 0 && isActive) {
      setIsActive(false);
      handleFinish();
    }
    return () => clearInterval(interval);
  }, [isActive, seconds]);

  const toggleTimer = () => setIsActive(!isActive);
  const resetTimer = () => {
    setIsActive(false);
    setSeconds(1500);
  };

  const formatTime = (secs: number) => {
    const mins = Math.floor(secs / 60);
    const rem = secs % 60;
    return `${mins.toString().padStart(2, '0')}:${rem.toString().padStart(2, '0')}`;
  };

  const handleFinish = () => {
    setCompleted(true);
    confetti({
      particleCount: 80,
      spread: 70,
      origin: { y: 0.6 },
    });
    onSessionComplete(50, 0.5);
  };

  const title = event?.title || lesson?.title || "Machine Learning Focus Session";
  const category = event?.category || lesson?.category || "Interactive Lecture";

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#14102e] border border-purple-500/30 rounded-3xl w-full max-w-xl p-6 sm:p-8 shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Glow backdrop */}
        <div className="absolute -top-16 -right-16 w-48 h-48 bg-purple-600/20 rounded-full blur-3xl pointer-events-none"></div>

        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-[#1e1844] hover:bg-[#2b225d] text-gray-400 hover:text-white flex items-center justify-center transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-2 mb-2">
          <span className="bg-purple-900/60 text-purple-300 text-[11px] font-bold px-3 py-1 rounded-full border border-purple-500/30 uppercase tracking-wider">
            {category}
          </span>
          <span className="text-emerald-400 text-xs font-semibold flex items-center gap-1">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span> Live Study Room
          </span>
        </div>

        <h2 className="text-xl sm:text-2xl font-extrabold text-white tracking-tight leading-snug mb-4">
          {title}
        </h2>

        {/* Timer Box */}
        <div className="my-6 bg-[#1b1540] border border-[#2f255e] rounded-2xl p-6 flex flex-col items-center justify-center shadow-inner">
          <span className="text-xs font-semibold text-purple-300 uppercase tracking-widest mb-1">
            Focus Timer
          </span>
          <div className="text-5xl sm:text-6xl font-black text-white tracking-widest font-mono my-2 text-transparent bg-clip-text bg-gradient-to-r from-purple-200 via-white to-purple-200">
            {formatTime(seconds)}
          </div>

          {/* Controls */}
          <div className="flex items-center gap-4 mt-4">
            <button
              onClick={toggleTimer}
              className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-xs font-bold transition-all shadow-md ${
                isActive
                  ? 'bg-amber-500 hover:bg-amber-600 text-white'
                  : 'bg-[#7c3aed] hover:bg-[#6d28d9] text-white shadow-glow-purple'
              }`}
            >
              {isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              <span>{isActive ? 'Pause' : 'Start Focus'}</span>
            </button>

            <button
              onClick={resetTimer}
              className="p-2.5 rounded-full bg-[#251d4e] hover:bg-[#322765] text-gray-300 hover:text-white transition-colors"
              title="Reset Timer"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Key Study Highlights */}
        <div className="space-y-2 mb-6">
          <p className="text-xs font-semibold text-gray-400 uppercase tracking-wider">Session Objectives:</p>
          <div className="space-y-1.5 text-xs text-gray-300">
            <div className="flex items-start gap-2 bg-[#1b163e]/60 p-2.5 rounded-xl border border-[#292054]">
              <span className="text-purple-400 font-bold">•</span>
              <span>Review loss function convexity and analytical gradient derivations.</span>
            </div>
            <div className="flex items-start gap-2 bg-[#1b163e]/60 p-2.5 rounded-xl border border-[#292054]">
              <span className="text-purple-400 font-bold">•</span>
              <span>Test knowledge with the interactive quiz to cement key concepts.</span>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-between pt-2 border-t border-[#251d52]">
          <span className="text-xs text-purple-300 font-medium flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-purple-400" /> +50 Points upon completion
          </span>

          <button
            onClick={handleFinish}
            disabled={completed}
            className={`flex items-center gap-2 px-6 py-2.5 rounded-full text-xs font-bold transition-all ${
              completed
                ? 'bg-emerald-600 text-white cursor-default'
                : 'bg-white hover:bg-gray-100 text-[#0c0a1a] shadow-lg hover:scale-105 active:scale-95'
            }`}
          >
            <CheckCircle2 className="w-4 h-4" />
            <span>{completed ? 'Session Completed!' : 'Mark Completed'}</span>
          </button>
        </div>
      </div>
    </div>
  );
};
