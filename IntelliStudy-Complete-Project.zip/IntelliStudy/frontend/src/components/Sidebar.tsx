import React from 'react';
import { 
  Home, 
  Brain, 
  BookOpen, 
  Calendar, 
  BarChart3, 
  Settings, 
  HelpCircle, 
  LogOut 
} from 'lucide-react';

interface SidebarProps {
  currentTab: string;
  setCurrentTab: (tab: string) => void;
  openSettings: () => void;
  openHelp: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  setCurrentTab,
  openSettings,
  openHelp,
}) => {
  const navItems = [
    { id: 'overview', icon: Home, label: 'Overview' },
    { id: 'quizzes', icon: Brain, label: 'Quizzes & Flashcards' },
    { id: 'notes', icon: BookOpen, label: 'Notes & Summaries' },
    { id: 'timetable', icon: Calendar, label: 'Study Timetable' },
    { id: 'analytics', icon: BarChart3, label: 'Performance' },
  ];

  return (
    <aside className="w-16 lg:w-20 flex-shrink-0 bg-[#0e0c1f] border-r border-[#221c45]/70 flex flex-col items-center justify-between py-5 z-20 select-none">
      {/* Top Logo - Waveform Icon matching reference image */}
      <div className="flex flex-col items-center space-y-6">
        <div 
          onClick={() => setCurrentTab('overview')}
          className="cursor-pointer group flex items-center justify-center w-11 h-11 rounded-2xl bg-[#1e1840]/60 border border-purple-500/20 hover:border-purple-400/50 transition-all duration-300"
          title="IntelliStudy AI"
        >
          {/* Stylized Audio/Pulse Waveform icon from image */}
          <div className="flex items-center gap-[2.5px]">
            <span className="w-[3px] h-2.5 bg-purple-400 rounded-full"></span>
            <span className="w-[3px] h-5 bg-purple-300 rounded-full"></span>
            <span className="w-[3px] h-7 bg-white rounded-full"></span>
            <span className="w-[3px] h-4 bg-purple-300 rounded-full"></span>
            <span className="w-[3px] h-2 bg-purple-400 rounded-full"></span>
          </div>
        </div>

        {/* Navigation Items */}
        <nav className="flex flex-col space-y-3">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = currentTab === item.id;
            return (
              <button
                key={item.id}
                onClick={() => setCurrentTab(item.id)}
                title={item.label}
                className={`relative w-11 h-11 rounded-2xl flex items-center justify-center transition-all duration-200 group ${
                  isActive
                    ? 'bg-[#7c3aed] text-white shadow-glow-purple ring-1 ring-purple-400/50'
                    : 'text-gray-400 hover:text-white hover:bg-[#1a1638]'
                }`}
              >
                <Icon className={`w-4 h-4 transition-transform duration-200 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`} />
              </button>
            );
          })}

          {/* Settings Trigger */}
          <button
            onClick={openSettings}
            title="Settings & Gemini API"
            className="w-11 h-11 rounded-2xl flex items-center justify-center text-gray-400 hover:text-white hover:bg-[#1a1638] transition-all duration-200 group"
          >
            <Settings className="w-4 h-4 group-hover:rotate-45 transition-transform duration-300" />
          </button>
        </nav>
      </div>

      {/* Bottom Actions */}
      <div className="flex flex-col space-y-3 items-center">
        <button
          onClick={openHelp}
          title="Help & Study Tips"
          className="w-9 h-9 rounded-xl flex items-center justify-center text-gray-400 hover:text-white hover:bg-[#1a1638] transition-all"
        >
          <HelpCircle className="w-4 h-4" />
        </button>

        <button
          onClick={() => {
            if (confirm("Reset current study session demo data?")) {
              window.location.reload();
            }
          }}
          title="Sign Out / Switch Session"
          className="w-9 h-9 rounded-xl flex items-center justify-center text-gray-400 hover:text-rose-400 hover:bg-[#1a1638] transition-all"
        >
          <LogOut className="w-4 h-4" />
        </button>
      </div>
    </aside>
  );
};
