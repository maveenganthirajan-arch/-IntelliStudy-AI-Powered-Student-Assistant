import React from 'react';
import { X, BookOpen, Brain, Calendar, BarChart3, Sparkles } from 'lucide-react';

interface HelpModalProps {
  onClose: () => void;
}

export const HelpModal: React.FC<HelpModalProps> = ({ onClose }) => {
  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#14102e] border border-purple-500/30 rounded-3xl w-full max-w-xl p-6 sm:p-8 shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-[#1e1844] hover:bg-[#2b225d] text-gray-400 hover:text-white flex items-center justify-center transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        <h3 className="text-xl font-bold text-white mb-2 flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-purple-400" />
          <span>IntelliStudy Quick Guide</span>
        </h3>
        <p className="text-xs text-gray-400 mb-6">
          How to get the most out of your AI-Powered Student Assistant:
        </p>

        <div className="space-y-3.5 text-xs">
          <div className="flex items-start gap-3 bg-[#19143a] p-3.5 rounded-2xl border border-[#2d225e]">
            <BookOpen className="w-5 h-5 text-purple-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block font-bold mb-0.5">1. Upload & Summarize Notes</strong>
              <p className="text-gray-300">Drop PDF lecture slides or paste text in the Notes tab. Gemini automatically extracts key takeaways, core concepts, and formulas.</p>
            </div>
          </div>

          <div className="flex items-start gap-3 bg-[#19143a] p-3.5 rounded-2xl border border-[#2d225e]">
            <Brain className="w-5 h-5 text-indigo-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block font-bold mb-0.5">2. Generate Quizzes & Flashcards</strong>
              <p className="text-gray-300">Practice with interactive MCQs and flip 3D flashcards. Correct answers earn study points towards your weekly goal.</p>
            </div>
          </div>

          <div className="flex items-start gap-3 bg-[#19143a] p-3.5 rounded-2xl border border-[#2d225e]">
            <Calendar className="w-5 h-5 text-emerald-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block font-bold mb-0.5">3. Study Timetable & Calendar</strong>
              <p className="text-gray-300">Follow the timeline on the Overview dashboard. Click "Join" to open the Pomodoro focus timer and complete scheduled study sessions.</p>
            </div>
          </div>

          <div className="flex items-start gap-3 bg-[#19143a] p-3.5 rounded-2xl border border-[#2d225e]">
            <BarChart3 className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
            <div>
              <strong className="text-white block font-bold mb-0.5">4. Track Performance & Metrics</strong>
              <p className="text-gray-300">Monitor your daily study hours, weekly progression, and subject competence breakdown in the Performance tab.</p>
            </div>
          </div>
        </div>

        <div className="mt-6 pt-4 border-t border-[#251d52] flex justify-end">
          <button
            onClick={onClose}
            className="px-6 py-2.5 rounded-full bg-[#7c3aed] text-white text-xs font-bold hover:bg-[#6d28d9] transition-all shadow-glow-purple"
          >
            Got it, let's study!
          </button>
        </div>
      </div>
    </div>
  );
};
