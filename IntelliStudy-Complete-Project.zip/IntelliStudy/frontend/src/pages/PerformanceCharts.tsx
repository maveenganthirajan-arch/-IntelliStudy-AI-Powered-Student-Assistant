import React from 'react';
import { 
  BarChart3, 
  TrendingUp, 
  Award, 
  Flame, 
  BookOpen, 
  Clock, 
  Target, 
  CheckCircle2, 
  Zap 
} from 'lucide-react';
import { DashboardData } from '../types';

interface PerformanceChartsProps {
  data?: DashboardData | null;
  onNavigateTab: (tab: string) => void;
}

export const PerformanceCharts: React.FC<PerformanceChartsProps> = ({ data, onNavigateTab }) => {
  const user = data?.user;
  const weeklyHours = data?.weekly_hours || [
    { day: 'Mon', hours: 2.2, target: 2.5 },
    { day: 'Tue', hours: 3.8, target: 2.5 },
    { day: 'Wed', hours: 1.4, target: 2.5 },
    { day: 'Thu', hours: 2.9, target: 2.5 },
    { day: 'Fri', hours: 3.1, target: 2.5 },
    { day: 'Sat', hours: 1.0, target: 1.5 },
    { day: 'Sun', hours: 0.5, target: 1.5 },
  ];

  const subjects = data?.subject_mastery || [
    { subject: 'Neural Networks & Backpropagation', score: 88, color: '#8b5cf6' },
    { subject: 'Supervised Learning Algorithms', score: 94, color: '#10b981' },
    { subject: 'Loss Functions & Optimization', score: 76, color: '#f59e0b' },
    { subject: 'Natural Language & Transformers', score: 82, color: '#06b6d4' },
  ];

  const maxWeeklyHour = Math.max(...weeklyHours.map((d) => d.hours), 4.5);

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-[#221c45]">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-wide">
            Performance Analytics & Charts
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Track your study hours, topic mastery progression, and quiz retention statistics.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <div className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-purple-900/40 text-purple-300 border border-purple-500/30 text-xs font-bold">
            <Award className="w-4 h-4 text-purple-400" />
            <span>Scholar Level: Gold</span>
          </div>

          <div className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-amber-950/40 text-amber-300 border border-amber-500/30 text-xs font-bold">
            <Flame className="w-4 h-4 text-amber-400" />
            <span>{data?.study_streak_days || 14} Day Streak</span>
          </div>
        </div>
      </div>

      {/* Grid: 2 Large Analytical Panels */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Panel 1: Weekly Study Hours Bar Chart (7 cols) */}
        <div className="lg:col-span-7 glass-panel rounded-3xl p-6 sm:p-8 border border-[#2b2258]/60 shadow-xl space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-lg font-bold text-white flex items-center gap-2">
                <BarChart3 className="w-5 h-5 text-purple-400" />
                <span>Weekly Study Hours</span>
              </h3>
              <p className="text-xs text-gray-400 mt-0.5">
                Total this week: <strong className="text-white">{user?.study_hours || 8.4} hours</strong>
              </p>
            </div>

            <div className="flex items-center gap-4 text-xs font-semibold">
              <span className="flex items-center gap-1.5 text-purple-300">
                <span className="w-3 h-3 rounded-sm bg-[#7c3aed]"></span> Actual
              </span>
              <span className="flex items-center gap-1.5 text-gray-400">
                <span className="w-3 h-0.5 bg-gray-500"></span> Daily Target
              </span>
            </div>
          </div>

          {/* Bar Chart Visualization */}
          <div className="h-64 flex items-end justify-between gap-3 pt-6 px-2 border-b border-[#251d52]">
            {weeklyHours.map((item, idx) => {
              const heightPct = (item.hours / maxWeeklyHour) * 100;
              const targetPct = (item.target / maxWeeklyHour) * 100;

              return (
                <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                  {/* Tooltip */}
                  <div className="absolute -top-10 opacity-0 group-hover:opacity-100 transition-opacity bg-[#1b1540] text-white text-[11px] font-bold px-2 py-1 rounded-md border border-purple-500/40 pointer-events-none shadow-lg whitespace-nowrap z-20">
                    {item.hours} hrs (target: {item.target}h)
                  </div>

                  {/* Target reference dashed bar */}
                  <div
                    className="absolute w-full border-b border-dashed border-gray-600/60 pointer-events-none z-10"
                    style={{ bottom: `${targetPct}%` }}
                  ></div>

                  {/* Actual Study Bar */}
                  <div
                    className="w-full max-w-[42px] bg-gradient-to-t from-[#581c87] via-[#7c3aed] to-[#c084fc] rounded-t-xl group-hover:brightness-110 transition-all duration-500 shadow-glow-purple relative overflow-hidden"
                    style={{ height: `${heightPct}%` }}
                  >
                    <div className="absolute inset-0 bg-white/10 opacity-0 group-hover:opacity-100 transition-opacity"></div>
                  </div>

                  {/* Day Label */}
                  <span className="text-xs font-semibold text-gray-400 mt-3 group-hover:text-white transition-colors">
                    {item.day}
                  </span>
                </div>
              );
            })}
          </div>

          {/* Summary Metric Callouts */}
          <div className="grid grid-cols-3 gap-3 pt-2">
            <div className="bg-[#181338]/60 p-3.5 rounded-2xl border border-[#2b2258]">
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Average Daily</span>
              <p className="text-base font-extrabold text-white mt-0.5">2.1 Hours</p>
            </div>
            <div className="bg-[#181338]/60 p-3.5 rounded-2xl border border-[#2b2258]">
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Most Active Day</span>
              <p className="text-base font-extrabold text-purple-400 mt-0.5">Tuesday (3.8h)</p>
            </div>
            <div className="bg-[#181338]/60 p-3.5 rounded-2xl border border-[#2b2258]">
              <span className="text-[10px] text-gray-400 font-bold uppercase tracking-wider">Target Met</span>
              <p className="text-base font-extrabold text-emerald-400 mt-0.5">5 of 7 Days</p>
            </div>
          </div>
        </div>

        {/* Panel 2: Subject Mastery Progression (5 cols) */}
        <div className="lg:col-span-5 glass-panel rounded-3xl p-6 sm:p-8 border border-[#2b2258]/60 shadow-xl space-y-6">
          <div>
            <h3 className="text-lg font-bold text-white flex items-center gap-2">
              <TrendingUp className="w-5 h-5 text-emerald-400" />
              <span>Subject Competence</span>
            </h3>
            <p className="text-xs text-gray-400 mt-0.5">
              Knowledge retention calculated from quiz scores & flashcards.
            </p>
          </div>

          {/* Mastery Progress Bars */}
          <div className="space-y-4 pt-1">
            {subjects.map((sub, idx) => {
              return (
                <div key={idx} className="space-y-1.5">
                  <div className="flex items-center justify-between text-xs font-semibold">
                    <span className="text-gray-200">{sub.subject}</span>
                    <span className="text-purple-300 font-bold">{sub.score}%</span>
                  </div>

                  <div className="w-full h-2 bg-[#120e29] rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-1000"
                      style={{
                        width: `${sub.score}%`,
                        backgroundColor: sub.color,
                      }}
                    ></div>
                  </div>
                </div>
              );
            })}
          </div>

          {/* Overall Quiz Accuracy Card */}
          <div className="bg-gradient-to-br from-[#1e1742] to-[#120e2a] border border-[#34296c] rounded-2xl p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-purple-300 uppercase tracking-wider">
                Overall Accuracy
              </span>
              <span className="text-xs text-emerald-400 font-bold bg-emerald-950/60 px-2.5 py-0.5 rounded-full border border-emerald-500/30">
                Top 5% of Students
              </span>
            </div>

            <div className="flex items-baseline gap-2">
              <span className="text-3xl font-black text-white">91.4%</span>
              <span className="text-xs text-gray-400">across 18 quizzes taken</span>
            </div>

            <button
              onClick={() => onNavigateTab('quizzes')}
              className="w-full py-2.5 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs font-bold transition-all shadow-glow-purple flex items-center justify-center gap-1.5"
            >
              <Zap className="w-4 h-4" />
              <span>Take a Quiz to Level Up</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
