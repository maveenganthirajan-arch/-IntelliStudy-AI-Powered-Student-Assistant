import React, { useState } from 'react';
import { CalendarTimeline } from '../components/CalendarTimeline';
import { StatsLessons } from '../components/StatsLessons';
import { GreetingAndAssistant } from '../components/GreetingAndAssistant';
import { StudySessionModal } from '../components/StudySessionModal';
import { UserProfile, LessonProgress, TimetableEvent } from '../types';
import { updateLessonProgress, toggleTimetableComplete } from '../services/api';

interface OverviewDashboardProps {
  user?: UserProfile;
  lastLessons: LessonProgress[];
  events: TimetableEvent[];
  onRefreshDashboard: () => void;
  onNavigateTab: (tab: string) => void;
}

export const OverviewDashboard: React.FC<OverviewDashboardProps> = ({
  user,
  lastLessons,
  events,
  onRefreshDashboard,
  onNavigateTab,
}) => {
  const [selectedEvent, setSelectedEvent] = useState<TimetableEvent | null>(null);
  const [selectedLesson, setSelectedLesson] = useState<LessonProgress | null>(null);
  const [isModalOpen, setIsModalOpen] = useState(false);

  const handleJoinSession = (event: TimetableEvent) => {
    setSelectedEvent(event);
    setSelectedLesson(null);
    setIsModalOpen(true);
  };

  const handleContinueLesson = (lesson: LessonProgress) => {
    setSelectedLesson(lesson);
    setSelectedEvent(null);
    setIsModalOpen(true);
  };

  const handleSessionComplete = async (pointsEarned: number, hoursAdded: number) => {
    if (selectedEvent) {
      await toggleTimetableComplete(selectedEvent.id);
    }
    if (selectedLesson) {
      const nextProgress = Math.min(100, selectedLesson.progress_pct + 15);
      await updateLessonProgress(selectedLesson.id, nextProgress);
    }
    onRefreshDashboard();
    setTimeout(() => {
      setIsModalOpen(false);
    }, 1500);
  };

  return (
    <div className="p-4 lg:p-6 max-w-[1600px] mx-auto h-[calc(100vh-64px)] flex flex-col justify-start">
      {/* 3-Column Dashboard Grid exactly matching Reference Image proportions */}
      <div className="grid grid-cols-1 lg:grid-cols-[1.1fr_1.35fr_1fr] gap-4 lg:gap-5 items-stretch flex-1 min-h-0">
        {/* Left Column: Calendar & Timeline */}
        <div className="h-full min-h-[560px]">
          <CalendarTimeline
            events={events}
            onJoinSession={handleJoinSession}
            onToggleComplete={async (id) => {
              await toggleTimetableComplete(id);
              onRefreshDashboard();
            }}
          />
        </div>

        {/* Middle Column: Stats & Last Lessons */}
        <div className="h-full min-h-[560px]">
          <StatsLessons
            user={user}
            lastLessons={lastLessons}
            onContinueLesson={handleContinueLesson}
          />
        </div>

        {/* Right Column: Greeting & AI Assistant */}
        <div className="h-full min-h-[560px]">
          <GreetingAndAssistant
            user={user}
            onNavigateTab={onNavigateTab}
          />
        </div>
      </div>

      {/* Interactive Study Session Modal */}
      {isModalOpen && (
        <StudySessionModal
          event={selectedEvent}
          lesson={selectedLesson}
          onClose={() => setIsModalOpen(false)}
          onSessionComplete={handleSessionComplete}
        />
      )}
    </div>
  );
};
