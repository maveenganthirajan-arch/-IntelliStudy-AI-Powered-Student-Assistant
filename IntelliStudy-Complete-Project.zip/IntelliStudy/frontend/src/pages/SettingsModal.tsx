import React, { useState, useEffect } from 'react';
import { X, Key, Database, Sparkles, Check, Server, Shield, ExternalLink } from 'lucide-react';
import { SettingsData, UserProfile } from '../types';
import { getSettings, updateSettings } from '../services/api';

interface SettingsModalProps {
  user?: UserProfile;
  onClose: () => void;
  onRefreshDashboard: () => void;
}

export const SettingsModal: React.FC<SettingsModalProps> = ({
  user,
  onClose,
  onRefreshDashboard,
}) => {
  const [apiKey, setApiKey] = useState('');
  const [model, setModel] = useState('gemini-1.5-flash');
  const [settingsData, setSettingsData] = useState<SettingsData | null>(null);
  const [saved, setSaved] = useState(false);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchConfig();
  }, []);

  const fetchConfig = async () => {
    try {
      const data = await getSettings();
      setSettingsData(data);
      setModel(data.gemini_model || 'gemini-1.5-flash');
    } catch (err) {
      console.error(err);
    }
  };

  const handleSave = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await updateSettings({
        gemini_api_key: apiKey.trim() ? apiKey.trim() : undefined,
        gemini_model: model,
      });
      setSaved(true);
      fetchConfig();
      onRefreshDashboard();
      setTimeout(() => setSaved(false), 2500);
    } catch (err) {
      alert("Error saving settings.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
      <div className="bg-[#14102e] border border-purple-500/30 rounded-3xl w-full max-w-xl p-6 sm:p-8 shadow-2xl relative overflow-hidden animate-in fade-in zoom-in-95 duration-200">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 w-8 h-8 rounded-full bg-[#1e1844] hover:bg-[#2b225d] text-gray-400 hover:text-white flex items-center justify-center transition-colors"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="flex items-center gap-2 mb-2">
          <div className="w-8 h-8 rounded-xl bg-purple-900/60 border border-purple-500/40 flex items-center justify-center text-purple-300">
            <Key className="w-4 h-4" />
          </div>
          <h2 className="text-xl font-bold text-white tracking-wide">
            Settings & Integrations
          </h2>
        </div>
        <p className="text-xs text-gray-400 mb-6">
          Configure Google Gemini API key and verify PostgreSQL database connectivity.
        </p>

        {/* Database Status Card */}
        <div className="bg-[#1b1540] border border-[#2e245c] rounded-2xl p-4 mb-6 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-emerald-950/60 border border-emerald-500/40 flex items-center justify-center text-emerald-400">
              <Database className="w-4 h-4" />
            </div>
            <div>
              <span className="text-xs font-bold text-white block">
                Database Engine: {settingsData?.database_type || 'Active'}
              </span>
              <span className="text-[11px] text-gray-400">
                SQLAlchemy engine initialized with persistent tables
              </span>
            </div>
          </div>

          <span className="text-[11px] font-bold text-emerald-400 bg-emerald-950/60 px-2.5 py-1 rounded-full border border-emerald-500/30 flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
            Connected
          </span>
        </div>

        {/* Form */}
        <form onSubmit={handleSave} className="space-y-4">
          <div>
            <div className="flex items-center justify-between mb-1.5">
              <label className="text-xs font-semibold text-gray-300 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-400" />
                <span>Google Gemini API Key</span>
              </label>
              <a
                href="https://aistudio.google.com/app/apikey"
                target="_blank"
                rel="noreferrer"
                className="text-[11px] text-purple-400 hover:text-purple-300 flex items-center gap-1"
              >
                <span>Get Free Key</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <input
              type="password"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              placeholder={
                settingsData?.gemini_api_key_configured
                  ? '•••••••••••••••••••••••••••••• (Configured)'
                  : 'Enter your AI Studio API key (AIzaSy...)'
              }
              className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
            />
            <p className="text-[10px] text-gray-500 mt-1">
              Note: When no key is entered, IntelliStudy automatically uses its built-in smart AI fallback engine so all features work immediately!
            </p>
          </div>

          <div>
            <label className="block text-xs font-semibold text-gray-300 mb-1.5">
              AI Generation Model
            </label>
            <select
              value={model}
              onChange={(e) => setModel(e.target.value)}
              className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
            >
              <option value="gemini-1.5-flash">Gemini 1.5 Flash (Fastest, High Quality)</option>
              <option value="gemini-2.0-flash">Gemini 2.0 Flash (Next-Gen Multimodal)</option>
              <option value="gemini-1.5-pro">Gemini 1.5 Pro (Deep Analytical Reasoning)</option>
            </select>
          </div>

          <div className="flex items-center justify-between pt-4 border-t border-[#251d52]">
            {saved ? (
              <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                <Check className="w-4 h-4" /> Settings updated successfully!
              </span>
            ) : (
              <span></span>
            )}

            <div className="flex items-center gap-3">
              <button
                type="button"
                onClick={onClose}
                className="px-5 py-2 text-xs font-semibold text-gray-400 hover:text-white"
              >
                Close
              </button>
              <button
                type="submit"
                disabled={loading}
                className="px-6 py-2.5 rounded-full bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs font-bold shadow-glow-purple disabled:opacity-50"
              >
                {loading ? 'Saving...' : 'Save Settings'}
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
