import React, { useState, useEffect } from 'react';
import { 
  Calendar as CalendarIcon, 
  Sparkles, 
  Plus, 
  Clock, 
  CheckCircle2, 
  Trash2, 
  BookOpen, 
  Zap 
} from 'lucide-react';
import { TimetableEvent } from '../types';
import { 
  getTimetable, 
  createTimetableEvent, 
  toggleTimetableComplete, 
  deleteTimetableEvent, 
  generateAITimetable 
} from '../services/api';

interface TimetablePlannerProps {
  onRefreshDashboard: () => void;
}

export const TimetablePlanner: React.FC<TimetablePlannerProps> = ({ onRefreshDashboard }) => {
  const [events, setEvents] = useState<TimetableEvent[]>([]);
  const [selectedDay, setSelectedDay] = useState<number>(2); // Default to Tuesday
  const [loading, setLoading] = useState(false);

  // New Event Modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [title, setTitle] = useState('');
  const [dayIndex, setDayIndex] = useState(2);
  const [startTime, setStartTime] = useState('12:00');
  const [endTime, setEndTime] = useState('13:45');
  const [category, setCategory] = useState('Lecture');
  const [desc, setDesc] = useState('');

  // AI Timetable Modal
  const [showAIModal, setShowAIModal] = useState(false);
  const [aiTopics, setAiTopics] = useState('Machine Learning, Deep Neural Networks, Backpropagation, Gradient Descent');
  const [dailyHours, setDailyHours] = useState(3.0);
  const [isGenerating, setIsGenerating] = useState(false);

  const days = [
    { label: 'Sunday', short: 'Su', idx: 0 },
    { label: 'Monday', short: 'Mo', idx: 1 },
    { label: 'Tuesday', short: 'Tu', idx: 2 },
    { label: 'Wednesday', short: 'We', idx: 3 },
    { label: 'Thursday', short: 'Th', idx: 4 },
    { label: 'Friday', short: 'Fr', idx: 5 },
    { label: 'Saturday', short: 'Sa', idx: 6 },
  ];

  useEffect(() => {
    fetchEvents();
  }, []);

  const fetchEvents = async () => {
    setLoading(true);
    try {
      const data = await getTimetable();
      setEvents(data);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleToggle = async (eventId: number) => {
    await toggleTimetableComplete(eventId);
    await fetchEvents();
    onRefreshDashboard();
  };

  const handleDelete = async (eventId: number) => {
    if (!confirm("Delete this session?")) return;
    await deleteTimetableEvent(eventId);
    setEvents(events.filter((e) => e.id !== eventId));
    onRefreshDashboard();
  };

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!title.trim()) return;

    try {
      const newEv = await createTimetableEvent({
        title,
        day_index: dayIndex,
        start_time: startTime,
        end_time: endTime,
        category,
        description: desc,
        attendees: ['/user_avatar.png'],
      });
      setEvents([...events, newEv]);
      setShowAddModal(false);
      setTitle('');
      setDesc('');
      onRefreshDashboard();
    } catch (err) {
      alert("Error adding study session.");
    }
  };

  const handleAIGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsGenerating(true);
    try {
      const topicsList = aiTopics.split(',').map((s) => s.trim()).filter(Boolean);
      const generated = await generateAITimetable(topicsList, dailyHours, 1);
      setEvents([...events, ...generated]);
      setShowAIModal(false);
      onRefreshDashboard();
    } catch (err) {
      alert("Error generating AI schedule.");
    } finally {
      setIsGenerating(false);
    }
  };

  const activeDayEvents = events.filter((e) => e.day_index === selectedDay);

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-[#221c45]">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-wide">
            Personalized Study Timetable
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Organize lectures, self-study slots, and revision milestones with AI-optimized scheduling.
          </p>
        </div>

        <div className="flex items-center gap-3">
          <button
            onClick={() => setShowAIModal(true)}
            className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-[#7c3aed] to-[#6366f1] text-white text-xs font-bold shadow-glow-purple hover:scale-105 active:scale-95 transition-all"
          >
            <Sparkles className="w-4 h-4" />
            <span>Generate AI Schedule</span>
          </button>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-white hover:bg-gray-100 text-[#0c0a1a] text-xs font-bold shadow-md hover:scale-105 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Add Session</span>
          </button>
        </div>
      </div>

      {/* Weekday Filter Selector */}
      <div className="grid grid-cols-7 gap-2">
        {days.map((d) => {
          const isSelected = selectedDay === d.idx;
          const dayCount = events.filter((e) => e.day_index === d.idx).length;
          return (
            <button
              key={d.idx}
              onClick={() => setSelectedDay(d.idx)}
              className={`py-3 px-2 rounded-2xl flex flex-col items-center justify-center transition-all ${
                isSelected
                  ? 'bg-white text-[#0c0a1a] font-black shadow-lg scale-105'
                  : 'bg-[#161233] text-gray-400 hover:bg-[#201844] hover:text-white'
              }`}
            >
              <span className="text-[11px] font-semibold">{d.short}</span>
              <span className="text-sm font-bold mt-0.5">{d.label.slice(0, 3)}</span>
              {dayCount > 0 && (
                <span
                  className={`mt-1 text-[9px] px-1.5 py-0.2 rounded-full font-bold ${
                    isSelected ? 'bg-purple-900 text-purple-200' : 'bg-purple-950 text-purple-300'
                  }`}
                >
                  {dayCount} {dayCount === 1 ? 'session' : 'sessions'}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Daily Sessions List */}
      <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-[#2b2258]/60 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-[#251d52]">
          <h3 className="text-lg font-bold text-white flex items-center gap-2">
            <CalendarIcon className="w-5 h-5 text-purple-400" />
            <span>{days[selectedDay].label} Schedule</span>
          </h3>
          <span className="text-xs text-gray-400">
            {activeDayEvents.length} Sessions Planned
          </span>
        </div>

        {activeDayEvents.length === 0 ? (
          <div className="text-center py-16 text-gray-400">
            <Clock className="w-10 h-10 mx-auto text-purple-400 opacity-40 mb-3" />
            <p className="text-sm font-semibold">No study sessions scheduled for {days[selectedDay].label}.</p>
            <p className="text-xs text-gray-500 mt-1">Click "Generate AI Schedule" to auto-populate your week!</p>
          </div>
        ) : (
          <div className="space-y-3">
            {activeDayEvents.map((ev) => {
              return (
                <div
                  key={ev.id}
                  className={`p-5 rounded-2xl border transition-all flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 ${
                    ev.is_completed
                      ? 'bg-[#15112e]/70 border-emerald-500/30 opacity-70'
                      : 'bg-[#1a143a]/80 border-[#2f255e] hover:border-purple-500/50'
                  }`}
                >
                  {/* Left Info */}
                  <div className="flex items-start gap-4">
                    <button
                      onClick={() => handleToggle(ev.id)}
                      className={`w-6 h-6 rounded-full border flex items-center justify-center transition-colors flex-shrink-0 mt-1 ${
                        ev.is_completed
                          ? 'bg-emerald-500 border-emerald-400 text-white'
                          : 'border-[#3f3277] hover:border-purple-400 text-transparent'
                      }`}
                      title={ev.is_completed ? 'Mark pending' : 'Mark completed'}
                    >
                      <CheckCircle2 className="w-4 h-4" />
                    </button>

                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-purple-400">
                          {ev.start_time} – {ev.end_time}
                        </span>
                        <span className="text-[10px] uppercase font-bold text-purple-300 bg-purple-950 px-2 py-0.5 rounded border border-purple-800/40">
                          {ev.category}
                        </span>
                      </div>
                      <h4
                        className={`text-sm sm:text-base font-bold ${
                          ev.is_completed ? 'line-through text-gray-400' : 'text-white'
                        }`}
                      >
                        {ev.title}
                      </h4>
                      {ev.description && (
                        <p className="text-xs text-gray-400 mt-1 leading-relaxed">
                          {ev.description}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Right Actions */}
                  <div className="flex items-center gap-3 ml-auto sm:ml-0">
                    <button
                      onClick={() => handleDelete(ev.id)}
                      className="p-2 text-gray-500 hover:text-rose-400 transition-colors"
                      title="Delete Session"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Manual Add Session Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#151132] border border-purple-500/30 rounded-3xl w-full max-w-lg p-6 sm:p-8 shadow-2xl relative">
            <h3 className="text-xl font-bold text-white mb-4">Add Study Session</h3>

            <form onSubmit={handleCreate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">Session Title</label>
                <input
                  type="text"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="e.g. Convolutional Architectures Lab"
                  className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">Day of Week</label>
                  <select
                    value={dayIndex}
                    onChange={(e) => setDayIndex(parseInt(e.target.value))}
                    className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                  >
                    {days.map((d) => (
                      <option key={d.idx} value={d.idx}>{d.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                  >
                    <option value="Lecture">Lecture</option>
                    <option value="Self-Study">Self-Study</option>
                    <option value="Quiz">Quiz</option>
                    <option value="Lab">Lab</option>
                    <option value="Review">Review</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">Start Time</label>
                  <input
                    type="time"
                    value={startTime}
                    onChange={(e) => setStartTime(e.target.value)}
                    className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                  />
                </div>

                <div>
                  <label className="block text-xs font-semibold text-gray-300 mb-1">End Time</label>
                  <input
                    type="time"
                    value={endTime}
                    onChange={(e) => setEndTime(e.target.value)}
                    className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl px-3 py-2 text-xs text-white focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">Description (Optional)</label>
                <textarea
                  rows={2}
                  value={desc}
                  onChange={(e) => setDesc(e.target.value)}
                  placeholder="Key goals or syllabus topics..."
                  className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl p-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-5 py-2 text-xs font-semibold text-gray-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-6 py-2.5 rounded-full bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs font-bold shadow-glow-purple"
                >
                  Add Session
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* AI Timetable Generator Modal */}
      {showAIModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#151132] border border-purple-500/30 rounded-3xl w-full max-w-lg p-6 sm:p-8 shadow-2xl relative">
            <h3 className="text-xl font-bold text-white mb-2">
              Generate AI Study Timetable
            </h3>
            <p className="text-xs text-gray-400 mb-6">
              Gemini AI will intelligently allocate review sessions, lectures, and self-study intervals.
            </p>

            <form onSubmit={handleAIGenerate} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">
                  Subjects & Topics (comma separated)
                </label>
                <textarea
                  rows={3}
                  value={aiTopics}
                  onChange={(e) => setAiTopics(e.target.value)}
                  placeholder="e.g. Machine Learning, Computer Vision, Transformers, Linear Algebra"
                  className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                ></textarea>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">
                  Daily Study Target: {dailyHours} hours / day
                </label>
                <input
                  type="range"
                  min="1"
                  max="6"
                  step="0.5"
                  value={dailyHours}
                  onChange={(e) => setDailyHours(parseFloat(e.target.value))}
                  className="w-full accent-purple-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowAIModal(false)}
                  className="px-5 py-2 text-xs font-semibold text-gray-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isGenerating}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs font-bold shadow-glow-purple disabled:opacity-50"
                >
                  {isGenerating ? (
                    <>
                      <Sparkles className="w-4 h-4 animate-spin" />
                      <span>Generating Schedule...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Build My Schedule</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
