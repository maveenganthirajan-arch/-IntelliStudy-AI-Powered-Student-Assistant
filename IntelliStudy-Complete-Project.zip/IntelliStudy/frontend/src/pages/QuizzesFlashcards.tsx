import React, { useState, useEffect } from 'react';
import { 
  Brain, 
  Layers, 
  Sparkles, 
  CheckCircle2, 
  XCircle, 
  RotateCw, 
  ArrowRight, 
  ArrowLeft, 
  Trophy, 
  Plus, 
  Clock, 
  Lightbulb, 
  Trash2 
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { Quiz, FlashcardDeck, QuizQuestion } from '../types';
import { 
  getQuizzes, 
  generateQuiz, 
  submitQuiz, 
  getFlashcardDecks, 
  generateFlashcards 
} from '../services/api';

interface QuizzesFlashcardsProps {
  initialTopic?: string;
  initialNoteId?: number;
  onRefreshDashboard: () => void;
}

export const QuizzesFlashcards: React.FC<QuizzesFlashcardsProps> = ({
  initialTopic,
  initialNoteId,
  onRefreshDashboard,
}) => {
  const [activeTab, setActiveTab] = useState<'quizzes' | 'flashcards'>('quizzes');
  
  // Quizzes State
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [activeQuiz, setActiveQuiz] = useState<Quiz | null>(null);
  const [currentQIndex, setCurrentQIndex] = useState(0);
  const [selectedAnswers, setSelectedAnswers] = useState<number[]>([]);
  const [quizSubmitted, setQuizSubmitted] = useState(false);
  const [quizScore, setQuizScore] = useState<{ score: number; total: number; pct: number; points: number } | null>(null);

  // Flashcards State
  const [decks, setDecks] = useState<FlashcardDeck[]>([]);
  const [activeDeck, setActiveDeck] = useState<FlashcardDeck | null>(null);
  const [currentCardIndex, setCurrentCardIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [showHint, setShowHint] = useState(false);
  const [masteredCount, setMasteredCount] = useState(0);

  // Generator Modal State
  const [showGenModal, setShowGenModal] = useState(false);
  const [genTopic, setGenTopic] = useState(initialTopic || 'Machine Learning & Neural Networks');
  const [genCount, setGenCount] = useState(5);
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const qList = await getQuizzes();
      setQuizzes(qList);
      if (qList.length > 0 && !activeQuiz) {
        setActiveQuiz(qList[0]);
        setSelectedAnswers(new Array(qList[0].questions.length).fill(-1));
      }

      const dList = await getFlashcardDecks();
      setDecks(dList);
      if (dList.length > 0 && !activeDeck) {
        setActiveDeck(dList[0]);
      }
    } catch (err) {
      console.error(err);
    }
  };

  const handleSelectQuiz = (q: Quiz) => {
    setActiveQuiz(q);
    setCurrentQIndex(0);
    setSelectedAnswers(new Array(q.questions.length).fill(-1));
    setQuizSubmitted(false);
    setQuizScore(null);
  };

  const handleChooseOption = (optIndex: number) => {
    if (quizSubmitted) return;
    const updated = [...selectedAnswers];
    updated[currentQIndex] = optIndex;
    setSelectedAnswers(updated);
  };

  const handleQuizSubmit = async () => {
    if (!activeQuiz) return;
    try {
      const result = await submitQuiz(activeQuiz.id, selectedAnswers);
      setQuizSubmitted(true);
      setQuizScore({
        score: result.score,
        total: result.total,
        pct: result.percentage,
        points: result.points_earned,
      });

      confetti({
        particleCount: 100,
        spread: 80,
        origin: { y: 0.6 },
      });

      onRefreshDashboard();
    } catch (err) {
      alert("Error submitting quiz results.");
    }
  };

  const handleCreateAI = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!genTopic.trim()) return;

    setIsGenerating(true);
    try {
      if (activeTab === 'quizzes') {
        const newQuiz = await generateQuiz(genTopic, initialNoteId, genCount);
        setQuizzes([newQuiz, ...quizzes]);
        handleSelectQuiz(newQuiz);
      } else {
        const newDeck = await generateFlashcards(genTopic, initialNoteId, genCount);
        setDecks([newDeck, ...decks]);
        setActiveDeck(newDeck);
        setCurrentCardIndex(0);
        setIsFlipped(false);
      }
      setShowGenModal(false);
      onRefreshDashboard();
    } catch (err) {
      alert("Error generating content with AI.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto">
      {/* Top Header & Tab Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-[#221c45]">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-wide">
            AI Quizzes & 3D Flashcards
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Test retention with AI-generated Multiple Choice Questions and spaced repetition 3D flashcards.
          </p>
        </div>

        <div className="flex items-center gap-3">
          {/* Tab Switcher */}
          <div className="bg-[#151132] p-1 rounded-2xl border border-[#2c225a] flex items-center">
            <button
              onClick={() => setActiveTab('quizzes')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'quizzes'
                  ? 'bg-[#7c3aed] text-white shadow-glow-purple'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Brain className="w-3.5 h-3.5" />
              <span>MCQ Quizzes</span>
            </button>
            <button
              onClick={() => setActiveTab('flashcards')}
              className={`flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-bold transition-all ${
                activeTab === 'flashcards'
                  ? 'bg-[#7c3aed] text-white shadow-glow-purple'
                  : 'text-gray-400 hover:text-white'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>3D Flashcards</span>
            </button>
          </div>

          {/* Generate New Button */}
          <button
            onClick={() => setShowGenModal(true)}
            className="flex items-center gap-2 px-4 py-2.5 rounded-full bg-white hover:bg-gray-100 text-[#0c0a1a] text-xs font-bold shadow-md hover:scale-105 active:scale-95 transition-all"
          >
            <Plus className="w-4 h-4" />
            <span>Generate with AI</span>
          </button>
        </div>
      </div>

      {/* QUIZZES TAB */}
      {activeTab === 'quizzes' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Quizzes List (4 cols) */}
          <div className="lg:col-span-4 glass-panel rounded-3xl p-5 border border-[#2b2258]/60 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-gray-400 px-1">
              Available Quizzes ({quizzes.length})
            </span>

            <div className="space-y-2.5 max-h-[620px] overflow-y-auto">
              {quizzes.map((q) => {
                const isSelected = activeQuiz?.id === q.id;
                return (
                  <div
                    key={q.id}
                    onClick={() => handleSelectQuiz(q)}
                    className={`p-4 rounded-2xl cursor-pointer transition-all border ${
                      isSelected
                        ? 'bg-[#221a4e] border-purple-500 shadow-glow-purple'
                        : 'bg-[#181335]/70 border-[#2a2254] hover:bg-[#201844] hover:border-purple-500/40'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold text-purple-400 uppercase tracking-widest bg-purple-950 px-2 py-0.5 rounded border border-purple-800/40">
                        {q.questions.length} MCQs
                      </span>
                      <span className="text-[11px] text-gray-400">
                        +{(q.questions.length * 25)} pts
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-white mt-1.5">{q.title}</h4>
                    <p className="text-[11px] text-gray-400 mt-0.5">{q.topic}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: Active Quiz Player (8 cols) */}
          <div className="lg:col-span-8">
            {activeQuiz && activeQuiz.questions.length > 0 ? (
              <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-[#2b2258]/60 shadow-xl space-y-6">
                {/* Quiz Header & Progress */}
                <div className="flex items-center justify-between pb-4 border-b border-[#251d52]">
                  <div>
                    <span className="text-[11px] font-semibold text-purple-400 uppercase tracking-wider">
                      Question {currentQIndex + 1} of {activeQuiz.questions.length}
                    </span>
                    <h3 className="text-lg font-bold text-white mt-0.5">
                      {activeQuiz.title}
                    </h3>
                  </div>

                  <div className="flex items-center gap-2">
                    <span className="text-xs font-semibold text-gray-400">
                      Progress: {selectedAnswers.filter((a) => a !== -1).length}/{activeQuiz.questions.length}
                    </span>
                  </div>
                </div>

                {/* Progress bar */}
                <div className="w-full h-1.5 bg-[#140f2b] rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-purple-500 to-indigo-400 transition-all duration-300"
                    style={{
                      width: `${((currentQIndex + 1) / activeQuiz.questions.length) * 100}%`,
                    }}
                  ></div>
                </div>

                {/* Question Card */}
                {(() => {
                  const q = activeQuiz.questions[currentQIndex];
                  const userAns = selectedAnswers[currentQIndex];
                  const isCorrect = userAns === q.answer_index;

                  return (
                    <div className="space-y-6">
                      <h4 className="text-base sm:text-lg font-bold text-white leading-relaxed">
                        {q.question}
                      </h4>

                      {/* Options */}
                      <div className="space-y-3">
                        {q.options.map((opt, optIdx) => {
                          const isSelected = userAns === optIdx;
                          let optStyle = 'bg-[#181338]/80 border-[#2e245e] hover:border-purple-500/60 text-gray-200';

                          if (quizSubmitted) {
                            if (optIdx === q.answer_index) {
                              optStyle = 'bg-emerald-950/60 border-emerald-500 text-emerald-200 shadow-sm';
                            } else if (isSelected && optIdx !== q.answer_index) {
                              optStyle = 'bg-rose-950/60 border-rose-500 text-rose-200';
                            }
                          } else if (isSelected) {
                            optStyle = 'bg-[#291f5a] border-purple-500 text-white shadow-glow-purple ring-1 ring-purple-400';
                          }

                          return (
                            <button
                              key={optIdx}
                              onClick={() => handleChooseOption(optIdx)}
                              className={`w-full text-left p-4 rounded-2xl border transition-all flex items-start gap-3 text-xs sm:text-sm font-medium ${optStyle}`}
                            >
                              <span className="w-6 h-6 rounded-full bg-[#120e29] border border-[#3b2e75] flex items-center justify-center text-xs font-bold flex-shrink-0 mt-0.5">
                                {String.fromCharCode(65 + optIdx)}
                              </span>
                              <span className="leading-snug pt-0.5">{opt}</span>
                            </button>
                          );
                        })}
                      </div>

                      {/* Explanation box after submit */}
                      {quizSubmitted && (
                        <div
                          className={`p-4 rounded-2xl border text-xs sm:text-sm leading-relaxed ${
                            isCorrect
                              ? 'bg-emerald-950/40 border-emerald-500/40 text-emerald-200'
                              : 'bg-rose-950/40 border-rose-500/40 text-rose-200'
                          }`}
                        >
                          <div className="font-bold flex items-center gap-1.5 mb-1">
                            {isCorrect ? (
                              <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                            ) : (
                              <XCircle className="w-4 h-4 text-rose-400" />
                            )}
                            <span>{isCorrect ? 'Correct!' : 'Incorrect'}</span>
                          </div>
                          <p className="text-gray-300 mt-1">{q.explanation}</p>
                        </div>
                      )}

                      {/* Navigation buttons */}
                      <div className="flex items-center justify-between pt-4 border-t border-[#251d52]">
                        <button
                          onClick={() => setCurrentQIndex((prev) => Math.max(0, prev - 1))}
                          disabled={currentQIndex === 0}
                          className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#1b1540] hover:bg-[#251d52] disabled:opacity-40 text-gray-300 text-xs font-semibold transition-colors"
                        >
                          <ArrowLeft className="w-4 h-4" /> Previous
                        </button>

                        {currentQIndex < activeQuiz.questions.length - 1 ? (
                          <button
                            onClick={() => setCurrentQIndex((prev) => prev + 1)}
                            className="flex items-center gap-1.5 px-5 py-2.5 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs font-bold transition-all shadow-glow-purple"
                          >
                            Next <ArrowRight className="w-4 h-4" />
                          </button>
                        ) : !quizSubmitted ? (
                          <button
                            onClick={handleQuizSubmit}
                            disabled={selectedAnswers.includes(-1)}
                            className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-lg"
                          >
                            <Trophy className="w-4 h-4" />
                            <span>Submit Answers</span>
                          </button>
                        ) : (
                          <button
                            onClick={() => handleSelectQuiz(activeQuiz)}
                            className="flex items-center gap-1.5 px-5 py-2 rounded-xl bg-[#261f55] hover:bg-[#342a73] text-purple-300 text-xs font-bold transition-colors"
                          >
                            <RotateCw className="w-4 h-4" /> Retake Quiz
                          </button>
                        )}
                      </div>

                      {/* Score Summary Banner */}
                      {quizScore && (
                        <div className="bg-gradient-to-r from-purple-900/40 via-indigo-900/40 to-purple-900/40 border border-purple-500/40 rounded-2xl p-4 flex items-center justify-between">
                          <div>
                            <span className="text-xs font-bold text-white">Quiz Completed!</span>
                            <p className="text-[11px] text-purple-300">
                              Score: {quizScore.score}/{quizScore.total} ({quizScore.pct}%)
                            </p>
                          </div>
                          <span className="text-emerald-400 font-extrabold text-sm bg-emerald-950/60 px-3 py-1.5 rounded-full border border-emerald-500/30">
                            +{quizScore.points} Points Earned!
                          </span>
                        </div>
                      )}
                    </div>
                  );
                })()}
              </div>
            ) : (
              <div className="glass-panel rounded-3xl p-16 border border-[#2b2258]/60 text-center text-gray-400">
                <Brain className="w-12 h-12 mx-auto text-purple-400 opacity-40 mb-3" />
                <p className="text-sm font-semibold">Select a quiz or click "Generate with AI" to create one.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* FLASHCARDS TAB */}
      {activeTab === 'flashcards' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
          {/* Left: Decks List (4 cols) */}
          <div className="lg:col-span-4 glass-panel rounded-3xl p-5 border border-[#2b2258]/60 space-y-3">
            <span className="text-xs font-bold uppercase tracking-wider text-gray-400 px-1">
              Flashcard Decks ({decks.length})
            </span>

            <div className="space-y-2.5 max-h-[620px] overflow-y-auto">
              {decks.map((d) => {
                const isSelected = activeDeck?.id === d.id;
                return (
                  <div
                    key={d.id}
                    onClick={() => {
                      setActiveDeck(d);
                      setCurrentCardIndex(0);
                      setIsFlipped(false);
                      setShowHint(false);
                    }}
                    className={`p-4 rounded-2xl cursor-pointer transition-all border ${
                      isSelected
                        ? 'bg-[#221a4e] border-purple-500 shadow-glow-purple'
                        : 'bg-[#181335]/70 border-[#2a2254] hover:bg-[#201844] hover:border-purple-500/40'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-[10px] font-bold text-indigo-400 uppercase tracking-widest bg-indigo-950 px-2 py-0.5 rounded border border-indigo-800/40">
                        {d.cards.length} Cards
                      </span>
                    </div>
                    <h4 className="text-xs font-bold text-white mt-1.5">{d.title}</h4>
                    <p className="text-[11px] text-gray-400 mt-0.5">{d.topic}</p>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Right: 3D Flip Flashcard Player (8 cols) */}
          <div className="lg:col-span-8">
            {activeDeck && activeDeck.cards.length > 0 ? (
              <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-[#2b2258]/60 shadow-xl space-y-6">
                {/* Header */}
                <div className="flex items-center justify-between pb-4 border-b border-[#251d52]">
                  <div>
                    <span className="text-[11px] font-semibold text-purple-400 uppercase tracking-wider">
                      Card {currentCardIndex + 1} of {activeDeck.cards.length}
                    </span>
                    <h3 className="text-lg font-bold text-white mt-0.5">
                      {activeDeck.title}
                    </h3>
                  </div>

                  <span className="text-xs text-gray-400">
                    Click card or press Space to flip
                  </span>
                </div>

                {/* 3D Flip Card Container */}
                {(() => {
                  const card = activeDeck.cards[currentCardIndex];
                  return (
                    <div className="perspective-1000 w-full min-h-[320px] cursor-pointer" onClick={() => setIsFlipped(!isFlipped)}>
                      <div
                        className={`relative w-full h-80 rounded-3xl transition-transform duration-700 transform-style-3d shadow-2xl ${
                          isFlipped ? 'rotate-y-180' : ''
                        }`}
                      >
                        {/* Front of Card */}
                        <div className="absolute inset-0 backface-hidden bg-gradient-to-br from-[#1d1740] to-[#140f2e] border-2 border-[#392d77] rounded-3xl p-8 flex flex-col justify-between shadow-glow-purple">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-purple-400 uppercase tracking-widest">
                              Question / Prompt
                            </span>
                            <span className="text-xs text-gray-400 font-semibold flex items-center gap-1">
                              <RotateCw className="w-3.5 h-3.5" /> Tap to flip
                            </span>
                          </div>

                          <div className="text-lg sm:text-xl font-bold text-white text-center leading-relaxed px-4">
                            {card.front}
                          </div>

                          <div className="flex items-center justify-between">
                            {card.hint && (
                              <button
                                onClick={(e) => {
                                  e.stopPropagation();
                                  setShowHint(!showHint);
                                }}
                                className="text-xs text-amber-400 flex items-center gap-1 hover:underline"
                              >
                                <Lightbulb className="w-3.5 h-3.5" />
                                <span>{showHint ? card.hint : 'Need a hint?'}</span>
                              </button>
                            )}
                            <span className="text-[11px] text-gray-500 ml-auto">
                              Front side
                            </span>
                          </div>
                        </div>

                        {/* Back of Card */}
                        <div className="absolute inset-0 backface-hidden rotate-y-180 bg-gradient-to-br from-[#171b40] to-[#0d122b] border-2 border-indigo-500/60 rounded-3xl p-8 flex flex-col justify-between shadow-2xl">
                          <div className="flex items-center justify-between">
                            <span className="text-[11px] font-bold text-indigo-400 uppercase tracking-widest">
                              Answer & Explanation
                            </span>
                            <span className="text-xs text-emerald-400 font-semibold flex items-center gap-1">
                              <CheckCircle2 className="w-3.5 h-3.5" /> Core Concept
                            </span>
                          </div>

                          <div className="text-sm sm:text-base text-gray-100 text-center leading-relaxed px-4 overflow-y-auto max-h-48">
                            {card.back}
                          </div>

                          <div className="text-right text-[11px] text-gray-500">
                            Back side
                          </div>
                        </div>
                      </div>
                    </div>
                  );
                })()}

                {/* Card Navigation and Spaced Repetition Controls */}
                <div className="flex items-center justify-between pt-4 border-t border-[#251d52]">
                  <button
                    onClick={() => {
                      setCurrentCardIndex((prev) => Math.max(0, prev - 1));
                      setIsFlipped(false);
                      setShowHint(false);
                    }}
                    disabled={currentCardIndex === 0}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#1b1540] hover:bg-[#251d52] disabled:opacity-40 text-gray-300 text-xs font-semibold transition-colors"
                  >
                    <ArrowLeft className="w-4 h-4" /> Previous
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() => {
                        setIsFlipped(false);
                        setShowHint(false);
                        if (currentCardIndex < activeDeck.cards.length - 1) {
                          setCurrentCardIndex((prev) => prev + 1);
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-rose-950/60 hover:bg-rose-900/60 text-rose-300 border border-rose-800/40 text-xs font-bold transition-all"
                    >
                      Need Review
                    </button>

                    <button
                      onClick={() => {
                        setIsFlipped(false);
                        setShowHint(false);
                        setMasteredCount((prev) => prev + 1);
                        if (currentCardIndex < activeDeck.cards.length - 1) {
                          setCurrentCardIndex((prev) => prev + 1);
                        } else {
                          confetti({ particleCount: 70, spread: 60 });
                        }
                      }}
                      className="px-4 py-2 rounded-xl bg-emerald-950/60 hover:bg-emerald-900/60 text-emerald-300 border border-emerald-800/40 text-xs font-bold transition-all"
                    >
                      Got It!
                    </button>
                  </div>

                  <button
                    onClick={() => {
                      setCurrentCardIndex((prev) =>
                        Math.min(activeDeck.cards.length - 1, prev + 1)
                      );
                      setIsFlipped(false);
                      setShowHint(false);
                    }}
                    disabled={currentCardIndex === activeDeck.cards.length - 1}
                    className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-[#7c3aed] hover:bg-[#6d28d9] disabled:opacity-40 text-white text-xs font-bold transition-all shadow-glow-purple"
                  >
                    Next <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ) : (
              <div className="glass-panel rounded-3xl p-16 border border-[#2b2258]/60 text-center text-gray-400">
                <Layers className="w-12 h-12 mx-auto text-purple-400 opacity-40 mb-3" />
                <p className="text-sm font-semibold">Select a flashcard deck to begin active recall.</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Generator Modal */}
      {showGenModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#151132] border border-purple-500/30 rounded-3xl w-full max-w-lg p-6 sm:p-8 shadow-2xl relative">
            <h3 className="text-xl font-bold text-white mb-2">
              Generate AI {activeTab === 'quizzes' ? 'Quiz' : 'Flashcards'}
            </h3>
            <p className="text-xs text-gray-400 mb-6">
              Enter any course topic or concept. Gemini AI will create structured questions with explanations.
            </p>

            <form onSubmit={handleCreateAI} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">
                  Topic or Subject
                </label>
                <input
                  type="text"
                  value={genTopic}
                  onChange={(e) => setGenTopic(e.target.value)}
                  placeholder="e.g. Convolutional Neural Networks, Backpropagation, Loss Functions"
                  className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl px-3.5 py-2.5 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">
                  Number of {activeTab === 'quizzes' ? 'Questions' : 'Cards'} ({genCount})
                </label>
                <input
                  type="range"
                  min="3"
                  max="10"
                  value={genCount}
                  onChange={(e) => setGenCount(parseInt(e.target.value))}
                  className="w-full accent-purple-500"
                />
              </div>

              <div className="flex items-center justify-end gap-3 pt-3">
                <button
                  type="button"
                  onClick={() => setShowGenModal(false)}
                  className="px-5 py-2 text-xs font-semibold text-gray-400 hover:text-white"
                >
                  Cancel
                </button>

                <button
                  type="submit"
                  disabled={isGenerating}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs font-bold shadow-glow-purple disabled:opacity-50"
                >
                  {isGenerating ? (
                    <>
                      <Sparkles className="w-4 h-4 animate-spin" />
                      <span>Generating with AI...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Generate Now</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
