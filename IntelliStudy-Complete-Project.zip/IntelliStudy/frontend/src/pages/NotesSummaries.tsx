import React, { useState, useEffect } from 'react';
import { 
  Upload, 
  FileText, 
  Sparkles, 
  CheckCircle, 
  Download, 
  Brain, 
  Layers, 
  Trash2, 
  Plus, 
  FileCheck,
  Code
} from 'lucide-react';
import { Note } from '../types';
import { getNotes, uploadNote, deleteNote } from '../services/api';

interface NotesSummariesProps {
  onNavigateToQuiz: (noteId: number, topic: string) => void;
  onNavigateToFlashcards: (noteId: number, topic: string) => void;
  onRefreshDashboard: () => void;
}

export const NotesSummaries: React.FC<NotesSummariesProps> = ({
  onNavigateToQuiz,
  onNavigateToFlashcards,
  onRefreshDashboard,
}) => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [loading, setLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [dragOver, setDragOver] = useState(false);

  // New Note Form State
  const [titleInput, setTitleInput] = useState('');
  const [textInput, setTextInput] = useState('');
  const [fileInput, setFileInput] = useState<File | null>(null);
  const [showUploadModal, setShowUploadModal] = useState(false);

  useEffect(() => {
    fetchNotes();
  }, []);

  const fetchNotes = async () => {
    setLoading(true);
    try {
      const data = await getNotes();
      setNotes(data);
      if (data.length > 0 && !selectedNote) {
        setSelectedNote(data[0]);
      }
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = async (file: File) => {
    setIsUploading(true);
    try {
      const newNote = await uploadNote(file, undefined, undefined);
      setNotes([newNote, ...notes]);
      setSelectedNote(newNote);
      setShowUploadModal(false);
      onRefreshDashboard();
    } catch (err) {
      alert("Error processing document with AI. Please try again.");
    } finally {
      setIsUploading(false);
    }
  };

  const handleTextSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!titleInput.trim() && !textInput.trim() && !fileInput) return;

    setIsUploading(true);
    try {
      const newNote = await uploadNote(fileInput || undefined, titleInput || undefined, textInput || undefined);
      setNotes([newNote, ...notes]);
      setSelectedNote(newNote);
      setShowUploadModal(false);
      setTitleInput('');
      setTextInput('');
      setFileInput(null);
      onRefreshDashboard();
    } catch (err) {
      alert("Error processing note with AI.");
    } finally {
      setIsUploading(false);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm("Are you sure you want to delete this study note?")) return;
    await deleteNote(id);
    const updated = notes.filter((n) => n.id !== id);
    setNotes(updated);
    setSelectedNote(updated[0] || null);
    onRefreshDashboard();
  };

  const exportMarkdown = (note: Note) => {
    let md = `# ${note.title}\n\n`;
    md += `## Executive Summary\n${note.summary}\n\n`;
    md += `## Key Takeaways\n`;
    note.key_takeaways?.forEach((t) => (md += `- ${t}\n`));
    md += `\n## Core Concepts\n`;
    note.concepts?.forEach((c) => (md += `### ${c.title}\n${c.description}\n\n`));
    if (note.formulas?.length) {
      md += `## Formulas & Equations\n`;
      note.formulas?.forEach((f) => (md += `### ${f.name}\n\`${f.formula}\`\n${f.explanation}\n\n`));
    }

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${note.title.toLowerCase().replace(/\s+/g, '_')}_summary.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="p-6 md:p-8 space-y-6 max-w-[1600px] mx-auto">
      {/* Top Bar */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-2 border-b border-[#221c45]">
        <div>
          <h2 className="text-2xl font-bold text-white tracking-wide">
            Notes & PDF Summaries
          </h2>
          <p className="text-xs text-gray-400 mt-1">
            Upload course slides, textbooks, and notes for instant AI summaries, concepts, and formulas.
          </p>
        </div>

        <button
          onClick={() => setShowUploadModal(true)}
          className="flex items-center gap-2 px-5 py-2.5 rounded-full bg-gradient-to-r from-[#7c3aed] to-[#6366f1] text-white text-xs font-bold shadow-glow-purple hover:scale-105 active:scale-95 transition-all"
        >
          <Upload className="w-4 h-4" />
          <span>Upload PDF / Note</span>
        </button>
      </div>

      {/* Main Grid: Left Notes List + Right Summary View */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left List of Notes (4 cols) */}
        <div className="lg:col-span-4 glass-panel rounded-3xl p-5 border border-[#2b2258]/60 space-y-3">
          <div className="flex items-center justify-between px-1 mb-2">
            <span className="text-xs font-bold uppercase tracking-wider text-gray-400">
              Study Library ({notes.length})
            </span>
          </div>

          <div className="space-y-2.5 max-h-[640px] overflow-y-auto pr-1">
            {notes.map((n) => {
              const isSelected = selectedNote?.id === n.id;
              return (
                <div
                  key={n.id}
                  onClick={() => setSelectedNote(n)}
                  className={`p-4 rounded-2xl cursor-pointer transition-all border ${
                    isSelected
                      ? 'bg-[#221a4e] border-purple-500 shadow-glow-purple'
                      : 'bg-[#181335]/70 border-[#2a2254] hover:bg-[#201844] hover:border-purple-500/40'
                  }`}
                >
                  <div className="flex items-start justify-between">
                    <div className="flex items-center gap-2">
                      <span className="p-1.5 rounded-lg bg-purple-900/50 text-purple-300">
                        <FileText className="w-4 h-4" />
                      </span>
                      <span className="text-[10px] font-bold uppercase tracking-wider text-purple-400 bg-purple-950 px-2 py-0.5 rounded border border-purple-800/40">
                        {n.file_type || 'PDF'}
                      </span>
                    </div>

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        handleDelete(n.id);
                      }}
                      className="text-gray-500 hover:text-rose-400 transition-colors p-1"
                      title="Delete Note"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <h4 className="text-xs font-bold text-white mt-2 line-clamp-1">
                    {n.title}
                  </h4>
                  <p className="text-[11px] text-gray-400 mt-1 line-clamp-2">
                    {n.summary || 'Summary generated by Gemini AI...'}
                  </p>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Detail: Structured AI Summary View (8 cols) */}
        <div className="lg:col-span-8">
          {selectedNote ? (
            <div className="glass-panel rounded-3xl p-6 sm:p-8 border border-[#2b2258]/60 shadow-xl space-y-6">
              {/* Header */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 pb-4 border-b border-[#251d52]">
                <div>
                  <span className="text-[11px] font-semibold text-purple-400 uppercase tracking-widest bg-purple-950/60 px-2.5 py-1 rounded-md border border-purple-800/40">
                    AI Study Note Summary
                  </span>
                  <h3 className="text-xl sm:text-2xl font-black text-white mt-2 tracking-tight">
                    {selectedNote.title}
                  </h3>
                </div>

                {/* Quick Action Buttons */}
                <div className="flex flex-wrap items-center gap-2">
                  <button
                    onClick={() => onNavigateToQuiz(selectedNote.id, selectedNote.title)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#211a4e] hover:bg-purple-900/60 text-purple-300 hover:text-white text-xs font-bold border border-purple-500/30 transition-all"
                  >
                    <Brain className="w-3.5 h-3.5 text-purple-400" />
                    <span>Create Quiz</span>
                  </button>

                  <button
                    onClick={() => onNavigateToFlashcards(selectedNote.id, selectedNote.title)}
                    className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-[#211a4e] hover:bg-purple-900/60 text-indigo-300 hover:text-white text-xs font-bold border border-purple-500/30 transition-all"
                  >
                    <Layers className="w-3.5 h-3.5 text-indigo-400" />
                    <span>Create Cards</span>
                  </button>

                  <button
                    onClick={() => exportMarkdown(selectedNote)}
                    className="p-2 rounded-xl bg-[#211a4e] hover:bg-[#2c2368] text-gray-300 hover:text-white border border-[#322765] transition-all"
                    title="Export Markdown File"
                  >
                    <Download className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* 1. Executive Summary */}
              <div>
                <h4 className="text-xs font-bold uppercase tracking-wider text-purple-400 flex items-center gap-1.5 mb-2">
                  <Sparkles className="w-4 h-4" /> Executive Summary
                </h4>
                <div className="bg-[#181338]/80 border border-[#2c225a] rounded-2xl p-4 text-xs sm:text-sm text-gray-200 leading-relaxed whitespace-pre-line">
                  {selectedNote.summary}
                </div>
              </div>

              {/* 2. Key Takeaways */}
              {selectedNote.key_takeaways?.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-emerald-400 flex items-center gap-1.5 mb-2">
                    <CheckCircle className="w-4 h-4" /> High-Yield Takeaways
                  </h4>
                  <div className="space-y-2">
                    {selectedNote.key_takeaways.map((takeaway, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-3 bg-[#181338]/60 border border-[#292055] p-3 rounded-xl text-xs text-gray-200"
                      >
                        <span className="w-5 h-5 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center text-[10px] font-bold flex-shrink-0 mt-0.5">
                          {idx + 1}
                        </span>
                        <span className="leading-relaxed">{takeaway}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 3. Core Concepts */}
              {selectedNote.concepts?.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-indigo-400 flex items-center gap-1.5 mb-2">
                    <Layers className="w-4 h-4" /> Key Concepts & Mechanisms
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {selectedNote.concepts.map((concept, idx) => (
                      <div
                        key={idx}
                        className="bg-[#181338]/70 border border-[#2b2259] p-4 rounded-xl"
                      >
                        <h5 className="text-xs font-bold text-white mb-1.5 flex items-center gap-1.5">
                          <span className="w-1.5 h-1.5 rounded-full bg-purple-400"></span>
                          {concept.title}
                        </h5>
                        <p className="text-[11px] text-gray-300 leading-relaxed">
                          {concept.description}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 4. Formulas & Mathematical Definitions */}
              {selectedNote.formulas?.length > 0 && (
                <div>
                  <h4 className="text-xs font-bold uppercase tracking-wider text-amber-400 flex items-center gap-1.5 mb-2">
                    <Code className="w-4 h-4" /> Mathematical Formulas & Rules
                  </h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                    {selectedNote.formulas.map((formula, idx) => (
                      <div
                        key={idx}
                        className="bg-[#181338]/70 border border-[#2b2259] p-4 rounded-xl font-mono"
                      >
                        <span className="text-[10px] font-sans font-bold text-gray-400 uppercase tracking-wider">
                          {formula.name}
                        </span>
                        <div className="bg-[#110d29] px-3 py-2 rounded-lg text-purple-300 text-xs my-1.5 border border-purple-900/40 overflow-x-auto">
                          {formula.formula}
                        </div>
                        {formula.explanation && (
                          <p className="text-[11px] font-sans text-gray-400">
                            {formula.explanation}
                          </p>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="glass-panel rounded-3xl p-16 border border-[#2b2258]/60 text-center text-gray-400">
              <FileText className="w-12 h-12 mx-auto text-purple-400 opacity-40 mb-3" />
              <p className="text-sm font-semibold">Select a study note to review its summary, or upload a new PDF.</p>
            </div>
          )}
        </div>
      </div>

      {/* Upload Modal */}
      {showUploadModal && (
        <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-md flex items-center justify-center p-4">
          <div className="bg-[#151132] border border-purple-500/30 rounded-3xl w-full max-w-xl p-6 sm:p-8 shadow-2xl relative">
            <h3 className="text-xl font-bold text-white mb-2">
              Upload PDF Notes or Paste Content
            </h3>
            <p className="text-xs text-gray-400 mb-6">
              IntelliStudy uses Gemini AI to extract key concepts, build summaries, and prepare quizzes.
            </p>

            {/* Drag & Drop Zone */}
            <div
              onDragOver={(e) => {
                e.preventDefault();
                setDragOver(true);
              }}
              onDragLeave={() => setDragOver(false)}
              onDrop={(e) => {
                e.preventDefault();
                setDragOver(false);
                if (e.dataTransfer.files && e.dataTransfer.files[0]) {
                  handleFileUpload(e.dataTransfer.files[0]);
                }
              }}
              className={`border-2 border-dashed rounded-2xl p-8 text-center transition-all cursor-pointer ${
                dragOver
                  ? 'border-purple-400 bg-purple-950/40'
                  : 'border-[#332966] bg-[#1a143d]/60 hover:border-purple-500/60'
              }`}
              onClick={() => document.getElementById('pdf-file-picker')?.click()}
            >
              <input
                id="pdf-file-picker"
                type="file"
                accept=".pdf,.txt,.md,.docx"
                className="hidden"
                onChange={(e) => {
                  if (e.target.files && e.target.files[0]) {
                    handleFileUpload(e.target.files[0]);
                  }
                }}
              />
              <Upload className="w-10 h-10 text-purple-400 mx-auto mb-3 animate-bounce" />
              <p className="text-xs font-bold text-white">
                Drag and drop your PDF here, or <span className="text-purple-400 underline">browse files</span>
              </p>
              <p className="text-[10px] text-gray-500 mt-1">Supports PDF, DOCX, TXT, Markdown (Max 25MB)</p>
            </div>

            <div className="relative my-6 text-center">
              <span className="bg-[#151132] px-3 text-xs text-gray-500 relative z-10">or paste text content</span>
              <div className="absolute inset-0 top-1/2 border-t border-[#292055]"></div>
            </div>

            <form onSubmit={handleTextSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">Note Title</label>
                <input
                  type="text"
                  value={titleInput}
                  onChange={(e) => setTitleInput(e.target.value)}
                  placeholder="e.g. Deep Learning & Backpropagation"
                  className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl px-3.5 py-2 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-300 mb-1">Notes Content</label>
                <textarea
                  rows={4}
                  value={textInput}
                  onChange={(e) => setTextInput(e.target.value)}
                  placeholder="Paste lecture notes or text to summarize..."
                  className="w-full bg-[#1b1540] border border-[#2f255e] rounded-xl p-3 text-xs text-white placeholder-gray-500 focus:outline-none focus:border-purple-500"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-3 pt-2">
                <button
                  type="button"
                  onClick={() => setShowUploadModal(false)}
                  className="px-5 py-2 text-xs font-semibold text-gray-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isUploading}
                  className="flex items-center gap-2 px-6 py-2.5 rounded-full bg-[#7c3aed] hover:bg-[#6d28d9] text-white text-xs font-bold shadow-glow-purple disabled:opacity-50"
                >
                  {isUploading ? (
                    <>
                      <Sparkles className="w-4 h-4 animate-spin" />
                      <span>Generating AI Summary...</span>
                    </>
                  ) : (
                    <>
                      <Sparkles className="w-4 h-4" />
                      <span>Process & Summarize</span>
                    </>
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
