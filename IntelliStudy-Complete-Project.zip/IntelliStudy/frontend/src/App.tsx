import React, { useState, useEffect } from 'react';
import { Sidebar } from './components/Sidebar';
import { Header } from './components/Header';
import { OverviewDashboard } from './pages/OverviewDashboard';
import { NotesSummaries } from './pages/NotesSummaries';
import { QuizzesFlashcards } from './pages/QuizzesFlashcards';
import { TimetablePlanner } from './pages/TimetablePlanner';
import { PerformanceCharts } from './pages/PerformanceCharts';
import { SettingsModal } from './pages/SettingsModal';
import { HelpModal } from './components/HelpModal';
import { DashboardData, TimetableEvent } from './types';
import { getDashboard, getTimetable } from './services/api';

export const App: React.FC = () => {
  const [currentTab, setCurrentTab] = useState<string>('overview');
  const [dashboardData, setDashboardData] = useState<DashboardData | null>(null);
  const [events, setEvents] = useState<TimetableEvent[]>([]);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const [isHelpOpen, setIsHelpOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Context for passing into quiz/flashcards from notes
  const [targetNoteId, setTargetNoteId] = useState<number | undefined>(undefined);
  const [targetTopic, setTargetTopic] = useState<string | undefined>(undefined);

  useEffect(() => {
    loadAllData();
  }, []);

  const loadAllData = async () => {
    try {
      const dData = await getDashboard();
      setDashboardData(dData);

      const tEvents = await getTimetable();
      setEvents(tEvents);
    } catch (err) {
      console.error("Error loading application state:", err);
    }
  };

  const handleQuickCreate = (type: 'note' | 'quiz' | 'event') => {
    if (type === 'note') {
      setCurrentTab('notes');
    } else if (type === 'quiz') {
      setCurrentTab('quizzes');
    } else if (type === 'event') {
      setCurrentTab('timetable');
    }
  };

  const handleNavigateToQuiz = (noteId: number, topic: string) => {
    setTargetNoteId(noteId);
    setTargetTopic(topic);
    setCurrentTab('quizzes');
  };

  const handleNavigateToFlashcards = (noteId: number, topic: string) => {
    setTargetNoteId(noteId);
    setTargetTopic(topic);
    setCurrentTab('quizzes');
  };

  const pageTitles: Record<string, string> = {
    overview: 'Overview',
    quizzes: 'Quizzes & Flashcards',
    notes: 'Notes & Summaries',
    timetable: 'Study Timetable',
    analytics: 'Performance Charts',
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0c0a1a] text-white">
      {/* 1. Left Vertical Sidebar matching reference image */}
      <Sidebar
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
        openSettings={() => setIsSettingsOpen(true)}
        openHelp={() => setIsHelpOpen(true)}
      />

      {/* 2. Main Content Area */}
      <div className="flex-1 flex flex-col h-full overflow-hidden">
        {/* Top Header matching reference image */}
        <Header
          title={pageTitles[currentTab] || 'Overview'}
          user={dashboardData?.user}
          onOpenQuickCreate={handleQuickCreate}
          onSearch={(q) => setSearchQuery(q)}
        />

        {/* Scrollable Viewport */}
        <main className="flex-1 overflow-y-auto bg-gradient-to-b from-[#0c0a1a] via-[#100c25] to-[#0c0a1a]">
          {currentTab === 'overview' && (
            <OverviewDashboard
              user={dashboardData?.user}
              lastLessons={dashboardData?.last_lessons || []}
              events={events}
              onRefreshDashboard={loadAllData}
              onNavigateTab={(tab) => setCurrentTab(tab)}
            />
          )}

          {currentTab === 'notes' && (
            <NotesSummaries
              onNavigateToQuiz={handleNavigateToQuiz}
              onNavigateToFlashcards={handleNavigateToFlashcards}
              onRefreshDashboard={loadAllData}
            />
          )}

          {currentTab === 'quizzes' && (
            <QuizzesFlashcards
              initialTopic={targetTopic}
              initialNoteId={targetNoteId}
              onRefreshDashboard={loadAllData}
            />
          )}

          {currentTab === 'timetable' && (
            <TimetablePlanner
              onRefreshDashboard={loadAllData}
            />
          )}

          {currentTab === 'analytics' && (
            <PerformanceCharts
              data={dashboardData}
              onNavigateTab={(tab) => setCurrentTab(tab)}
            />
          )}
        </main>
      </div>

      {/* Settings Modal */}
      {isSettingsOpen && (
        <SettingsModal
          user={dashboardData?.user}
          onClose={() => setIsSettingsOpen(false)}
          onRefreshDashboard={loadAllData}
        />
      )}

      {/* Help Modal */}
      {isHelpOpen && (
        <HelpModal
          onClose={() => setIsHelpOpen(false)}
        />
      )}
    </div>
  );
};

export default App;
