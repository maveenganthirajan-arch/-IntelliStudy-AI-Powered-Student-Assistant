export interface UserProfile {
  id: number;
  name: string;
  course: string;
  avatar_url: string;
  points: number;
  max_points: number;
  points_weekly_delta: number;
  study_hours: number;
  study_hours_delta_pct: number;
  completed_lessons: number;
  total_lessons: number;
  completion_rate_pct: number;
}

export interface LessonProgress {
  id: number;
  title: string;
  subtitle: string;
  progress_pct: number;
  last_accessed: string;
  category: string;
}

export interface TimetableEvent {
  id: number;
  title: string;
  day_index: number; // 0=Su, 1=Mo, 2=Tu, 3=We, 4=Th, 5=Fr, 6=Sa
  start_time: string;
  end_time: string;
  description?: string;
  category: string;
  attendees: string[];
  join_link: string;
  is_completed: boolean;
}

export interface ConceptItem {
  title: string;
  description: string;
}

export interface FormulaItem {
  name: string;
  formula: string;
  explanation?: string;
}

export interface Note {
  id: number;
  title: string;
  filename?: string;
  file_type: string;
  content: string;
  summary?: string;
  key_takeaways: string[];
  concepts: ConceptItem[];
  formulas: FormulaItem[];
  created_at: string;
  updated_at: string;
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  answer_index: number;
  explanation: string;
}

export interface Quiz {
  id: number;
  title: string;
  topic: string;
  note_id?: number;
  questions: QuizQuestion[];
  total_questions: number;
  created_at: string;
}

export interface QuizQuestionResult {
  question_id: number;
  question: string;
  options: string[];
  user_answer: number;
  correct_answer: number;
  is_correct: boolean;
  explanation: string;
}

export interface QuizSubmitResult {
  score: number;
  total: number;
  percentage: number;
  points_earned: number;
  results: QuizQuestionResult[];
}

export interface FlashcardItem {
  id: number;
  front: string;
  back: string;
  hint?: string;
}

export interface FlashcardDeck {
  id: number;
  title: string;
  topic: string;
  note_id?: number;
  cards: FlashcardItem[];
  created_at: string;
}

export interface WeeklyHourStat {
  day: string;
  hours: number;
  target: number;
}

export interface SubjectMastery {
  subject: string;
  score: number;
  color: string;
}

export interface DashboardData {
  user: UserProfile;
  last_lessons: LessonProgress[];
  weekly_hours: WeeklyHourStat[];
  subject_mastery: SubjectMastery[];
  study_streak_days: number;
  total_notes_count: number;
}

export interface ChatMessage {
  id?: number;
  sender: 'user' | 'assistant';
  message: string;
  timestamp?: string;
}

export interface SettingsData {
  gemini_api_key_configured: boolean;
  gemini_model: string;
  database_url_configured: boolean;
  database_type: string;
}
