/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        dark: {
          950: '#0b0918',
          900: '#100e24',
          850: '#15122e',
          800: '#1a1638',
          750: '#211c44',
          700: '#2a2455',
          600: '#383070',
        },
        brand: {
          purple: '#8b5cf6',
          violet: '#7c3aed',
          fuchsia: '#c026d3',
          neon: '#a855f7',
          glow: '#9333ea',
        }
      },
      fontFamily: {
        sans: ['Plus Jakarta Sans', 'Inter', 'system-ui', 'sans-serif'],
      },
      boxShadow: {
        'glow-purple': '0 0 25px -5px rgba(139, 92, 246, 0.4)',
        'glow-neon': '0 0 35px -5px rgba(168, 85, 247, 0.5)',
        'glass': '0 8px 32px 0 rgba(0, 0, 0, 0.37)',
      }
    },
  },
  plugins: [],
}
