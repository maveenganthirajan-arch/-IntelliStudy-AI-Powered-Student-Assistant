import os
import json
import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles

from app.config import settings
from app.database import engine, Base, SessionLocal
from app.models import UserProfile, LessonProgress, TimetableEvent, Note, Quiz, FlashcardDeck
from app.routes import notes, quizzes, flashcards, timetable, analytics, assistant, settings as settings_routes

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("intellistudy")

def seed_initial_data():
    """Seed initial data matching reference image and providing immediate interactive content."""
    Base.metadata.create_all(bind=engine)
    db = SessionLocal()
    try:
        # Seed UserProfile
        if not db.query(UserProfile).first():
            user = UserProfile(
                name="Anastasiia H.",
                course="AI Course",
                avatar_url="/user_avatar.png",
                points=836,
                max_points=1500,
                points_weekly_delta=290,
                study_hours=8.4,
                study_hours_delta_pct=-94,
                completed_lessons=62,
                total_lessons=105
            )
            db.add(user)

        # Seed Lesson Progress
        if db.query(LessonProgress).count() == 0:
            l1 = LessonProgress(
                title="Key AI Concepts You Should Know",
                subtitle="You can be better!",
                progress_pct=75,
                last_accessed="5 min ago",
                category="Machine Learning"
            )
            l2 = LessonProgress(
                title="AI Basics: Terms, Models, and Data",
                subtitle="You're almost done!",
                progress_pct=94,
                last_accessed="2 h ago",
                category="Foundations"
            )
            db.add_all([l1, l2])

        # Seed Timetable Events (Matches reference image Tuesday schedule!)
        if db.query(TimetableEvent).count() == 0:
            e1 = TimetableEvent(
                title="How Machine Learning Works: From Data to Decisions",
                day_index=2, # Tuesday (Tu 06 in image)
                start_time="12:00",
                end_time="13:45",
                category="Lecture",
                description="Comprehensive breakdown of ML pipelines, feature encoding, model selection, and decision boundaries.",
                attendees=json.dumps(["/user_avatar.png", "/mascot_avatar.png"]),
                join_link="#",
                is_completed=False
            )
            e2 = TimetableEvent(
                title="Neural Networks Explained: Patterns, Layers, Intelligence",
                day_index=2, # Tuesday (Tu 06 in image)
                start_time="16:00",
                end_time="17:45",
                category="Lecture",
                description="Mathematical and visual intuition behind feedforward layers, backpropagation, and non-linear representations.",
                attendees=json.dumps(["/user_avatar.png", "/mascot_avatar.png"]),
                join_link="#",
                is_completed=False
            )
            e3 = TimetableEvent(
                title="Gradient Descent & Loss Optimization Workshop",
                day_index=3, # Wednesday
                start_time="11:00",
                end_time="12:30",
                category="Lab",
                description="Practical coding session implementing Adam and SGD with momentum.",
                attendees=json.dumps(["/user_avatar.png"]),
                join_link="#",
                is_completed=False
            )
            db.add_all([e1, e2, e3])

        # Seed Sample Note
        if db.query(Note).count() == 0:
            sample_note = Note(
                title="Machine Learning Foundations & Deep Neural Networks",
                filename="machine_learning_foundations.md",
                file_type="markdown",
                content="""# Machine Learning Foundations & Deep Neural Networks

## Executive Summary
Machine learning is a subset of artificial intelligence focused on building systems that learn patterns from empirical data rather than through explicit rule programming. Core paradigms include Supervised Learning (predicting labeled outcomes), Unsupervised Learning (discovering latent data structures), and Reinforcement Learning (optimizing sequential decision policies).

## Deep Feedforward Networks
Deep feedforward networks, or multilayer perceptrons (MLPs), are the quintessential deep learning models. The goal of an MLP is to approximate some continuous function f*. A feedforward network defines a mapping y = f(x; θ) and learns the value of the parameters θ that result in the best function approximation.

### Backpropagation & Chain Rule
Training deep architectures relies on the backpropagation algorithm, which calculates partial derivatives of the scalar loss function L with respect to all internal weight matrices W and biases b using the chain rule of calculus.

### Non-Linear Activation Functions
Without non-linear activation functions such as ReLU, GELU, or Sigmoid, deep networks collapse into a composition of linear operators, severely limiting representation capacity.""",
                summary="This comprehensive study note surveys foundational machine learning principles and deep neural architectures. It details supervised vs. unsupervised paradigms, feedforward multilayer perceptrons, backpropagation via the multivariate chain rule, and the essential mathematical necessity of non-linear activation functions like ReLU and GELU.",
                key_takeaways=json.dumps([
                    "Machine learning models discover empirical patterns from data distributions rather than rigid handcrafted rules.",
                    "Multilayer perceptrons approximate complex non-linear functions through hierarchical feature abstractions.",
                    "Backpropagation computes exact analytical loss gradients via the chain rule to update weight parameters.",
                    "Non-linear activations prevent deep architectures from collapsing into trivial linear transformations.",
                    "Overfitting is actively mitigated through dropout, weight decay (L2 regularization), and early validation stopping."
                ]),
                concepts=json.dumps([
                    {"title": "Multilayer Perceptron (MLP)", "description": "Feedforward neural architecture consisting of an input layer, one or more hidden layers, and an output layer with parameterized weights."},
                    {"title": "Backpropagation", "description": "Reverse-mode automatic differentiation algorithm calculating gradients of loss with respect to every weight parameter."},
                    {"title": "ReLU Activation", "description": "Rectified Linear Unit f(x) = max(0, x), preventing vanishing gradients in positive domains and providing sparse activations."}
                ]),
                formulas=json.dumps([
                    {"name": "Cross-Entropy Loss", "formula": "L = - \\sum_{i=1}^C y_i \\log(\\hat{y}_i)", "explanation": "Quantifies difference between true distribution y and predicted class probability distribution y_hat."},
                    {"name": "Gradient Descent Step", "formula": "W_{t+1} = W_t - \\eta \\nabla_W L(W_t)", "explanation": "Weight parameter update with learning rate eta and loss gradient with respect to weights."}
                ])
            )
            db.add(sample_note)
            db.commit()
            db.refresh(sample_note)

            # Seed Sample Quiz linked to note
            sample_quiz = Quiz(
                title="Quiz: Machine Learning & Neural Networks",
                topic="Machine Learning Foundations",
                note_id=sample_note.id,
                questions=json.dumps([
                    {
                        "id": 1,
                        "question": "What is the primary mathematical reason for using non-linear activation functions in deep networks?",
                        "options": [
                            "To reduce matrix multiplication computational complexity to O(N)",
                            "To enable the network to approximate non-linear functions; without them, stacked layers collapse into a single linear map",
                            "To enforce strict binary outputs between 0 and 1",
                            "To eliminate the need for backpropagation calculations"
                        ],
                        "answer_index": 1,
                        "explanation": "Because a composition of linear transformations is mathematically equivalent to a single linear transformation, non-linear activations are required to give deep networks expressive non-linear approximation power."
                    },
                    {
                        "id": 2,
                        "question": "In reverse-mode automatic differentiation (backpropagation), which calculus principle is fundamentally applied?",
                        "options": [
                            "L'Hôpital's Rule",
                            "The Multivariate Chain Rule",
                            "Taylor Series Expansion",
                            "Lagrange Multipliers"
                        ],
                        "answer_index": 1,
                        "explanation": "The chain rule allows computing derivatives of composite functions layer by layer in reverse order from output loss to input weights."
                    },
                    {
                        "id": 3,
                        "question": "Which regularization technique deactivates a random subset of neurons during each training forward pass?",
                        "options": [
                            "Batch Normalization",
                            "Dropout Regularization",
                            "Gradient Clipping",
                            "Data Augmentation"
                        ],
                        "answer_index": 1,
                        "explanation": "Dropout prevents co-adaptation of feature detectors by randomly dropping units with probability p during training."
                    }
                ])
            )
            db.add(sample_quiz)

            # Seed Sample Flashcard Deck linked to note
            sample_deck = FlashcardDeck(
                title="Deck: Key AI & Deep Learning Concepts",
                topic="Deep Learning & AI",
                note_id=sample_note.id,
                cards=json.dumps([
                    {
                        "id": 1,
                        "front": "What is the Vanishing Gradient Problem?",
                        "back": "During backpropagation in deep networks using saturating activations (like sigmoid), gradients become exponentially smaller as they propagate backward, causing early layers to train extremely slowly or stall completely.",
                        "hint": "Think saturating activation derivatives."
                    },
                    {
                        "id": 2,
                        "front": "How does ReLU alleviate vanishing gradients?",
                        "back": "For positive inputs (x > 0), the derivative of ReLU is constant 1. This prevents gradients from shrinking as they pass through multiple layers.",
                        "hint": "Derivative is 1 for positive inputs."
                    },
                    {
                        "id": 3,
                        "front": "What is Cross-Entropy Loss measuring in classification?",
                        "back": "It measures the divergence between the true one-hot probability distribution of class labels and the softmax predicted probability distribution.",
                        "hint": "Negative log likelihood of correct class."
                    },
                    {
                        "id": 4,
                        "front": "Explain the difference between Batch, Mini-batch, and Stochastic Gradient Descent.",
                        "back": "Batch GD uses the entire dataset per update (slow, smooth); SGD uses 1 sample per update (fast, noisy); Mini-batch uses small subsets (e.g., 32-256 samples) balancing vectorization speed and gradient stability.",
                        "hint": "Compare dataset fraction per weight update."
                    }
                ])
            )
            db.add(sample_deck)

        db.commit()
        logger.info("[Database] Initial seeding completed successfully.")
    except Exception as e:
        db.rollback()
        logger.error(f"[Database Seed Error] {e}")
    finally:
        db.close()

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Starting IntelliStudy AI Backend...")
    seed_initial_data()
    yield
    # Shutdown
    logger.info("Shutting down IntelliStudy AI Backend...")

app = FastAPI(
    title=settings.app_name,
    version=settings.app_version,
    description="Intelligent study platform that helps students summarize notes, generate quizzes, and plan study schedules.",
    lifespan=lifespan
)

# CORS Middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Routes
app.include_router(notes.router)
app.include_router(quizzes.router)
app.include_router(flashcards.router)
app.include_router(timetable.router)
app.include_router(analytics.router)
app.include_router(assistant.router)
app.include_router(settings_routes.router)

@app.get("/api/health")
def health_check():
    return {
        "status": "healthy",
        "app": settings.app_name,
        "version": settings.app_version,
        "gemini_configured": bool(settings.gemini_api_key)
    }

# Mount uploads directory for static access
if os.path.exists(settings.upload_dir):
    app.mount("/uploads", StaticFiles(directory=settings.upload_dir), name="uploads")

# Mount built frontend if present
FRONTEND_DIST = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend", "dist")
if os.path.exists(FRONTEND_DIST):
    from fastapi.responses import FileResponse

    # Serve static assets
    assets_dir = os.path.join(FRONTEND_DIST, "assets")
    if os.path.exists(assets_dir):
        app.mount("/assets", StaticFiles(directory=assets_dir), name="assets")

    @app.get("/{full_path:path}")
    async def serve_frontend(full_path: str):
        file_path = os.path.join(FRONTEND_DIST, full_path)
        if os.path.isfile(file_path):
            return FileResponse(file_path)
        return FileResponse(os.path.join(FRONTEND_DIST, "index.html"))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
