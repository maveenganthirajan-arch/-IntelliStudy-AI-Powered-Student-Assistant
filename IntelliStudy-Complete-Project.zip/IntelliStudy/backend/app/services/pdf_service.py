import os
from pypdf import PdfReader

def extract_text_from_file(file_path: str) -> str:
    """Extract readable text from PDF, TXT, MD, etc."""
    ext = os.path.splitext(file_path)[1].lower()
    
    if ext == ".pdf":
        try:
            reader = PdfReader(file_path)
            extracted_pages = []
            for idx, page in enumerate(reader.pages):
                page_text = page.extract_text() or ""
                extracted_pages.append(f"--- Page {idx + 1} ---\n{page_text}")
            return "\n\n".join(extracted_pages).strip()
        except Exception as e:
            return f"Error reading PDF: {e}"
            
    elif ext in [".txt", ".md", ".json", ".csv"]:
        try:
            with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                return f.read().strip()
        except Exception as e:
            return f"Error reading text file: {e}"
            
    elif ext == ".docx":
        try:
            import docx
            doc = docx.Document(file_path)
            return "\n".join([p.text for p in doc.paragraphs]).strip()
        except Exception as e:
            return f"Error reading docx file: {e}"
            
    return ""
