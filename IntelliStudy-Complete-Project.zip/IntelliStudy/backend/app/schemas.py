from typing import List, Optional, Any
from pydantic import BaseModel
from datetime import datetime

# Profile & Dashboard
class UserProfileSchema(BaseModel):
    id: int
    name: str
    course: str
    avatar_url: str
    points: int
    max_points: int
    points_weekly_delta: int
    study_hours: float
    study_hours_delta_pct: int
    completed_lessons: int
    total_lessons: int
    completion_rate_pct: int = 59

    class Config:
        from_attributes = True

class UserProfileUpdate(BaseModel):
    name: Optional[str] = None
    course: Optional[str] = None
    avatar_url: Optional[str] = None
    points: Optional[int] = None
    study_hours: Optional[float] = None

class LessonProgressItem(BaseModel):
    id: int
    title: str
    subtitle: str
    progress_pct: int
    last_accessed: str
    category: str

    class Config:
        from_attributes = True

# Notes & Summaries
class ConceptItem(BaseModel):
    title: str
    description: str

class FormulaItem(BaseModel):
    name: str
    formula: str
    explanation: Optional[str] = None

class NoteCreate(BaseModel):
    title: str
    content: str
    filename: Optional[str] = None
    file_type: Optional[str] = "text"

class NoteResponse(BaseModel):
    id: int
    title: str
    filename: Optional[str] = None
    file_type: str
    content: str
    summary: Optional[str] = None
    key_takeaways: List[str] = []
    concepts: List[ConceptItem] = []
    formulas: List[FormulaItem] = []
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True

# Quizzes
class QuizQuestion(BaseModel):
    id: int
    question: str
    options: List[str]
    answer_index: int
    explanation: str

class QuizCreate(BaseModel):
    topic: str
    note_id: Optional[int] = None
    num_questions: int = 5
    content: Optional[str] = None

class QuizResponse(BaseModel):
    id: int
    title: str
    topic: str
    note_id: Optional[int] = None
    questions: List[QuizQuestion]
    total_questions: int
    created_at: datetime

class QuizSubmitRequest(BaseModel):
    quiz_id: int
    answers: List[int] # List of chosen option indexes

class QuizSubmitResponse(BaseModel):
    score: int
    total: int
    percentage: float
    points_earned: int
    results: List[dict] # {question_id, is_correct, user_answer, correct_answer, explanation}

# Flashcards
class FlashcardItem(BaseModel):
    id: int
    front: str
    back: str
    hint: Optional[str] = None

class FlashcardDeckCreate(BaseModel):
    topic: str
    note_id: Optional[int] = None
    num_cards: int = 6
    content: Optional[str] = None

class FlashcardDeckResponse(BaseModel):
    id: int
    title: str
    topic: str
    note_id: Optional[int] = None
    cards: List[FlashcardItem]
    created_at: datetime

# Timetable
class TimetableEventCreate(BaseModel):
    title: str
    day_index: int # 0=Su, 1=Mo, 2=Tu, 3=We, 4=Th, 5=Fr, 6=Sa
    start_time: str
    end_time: str
    description: Optional[str] = None
    category: Optional[str] = "Lecture"
    attendees: Optional[List[str]] = []
    join_link: Optional[str] = "#"

class TimetableEventResponse(BaseModel):
    id: int
    title: str
    day_index: int
    start_time: str
    end_time: str
    description: Optional[str] = None
    category: str
    attendees: List[str]
    join_link: str
    is_completed: bool

    class Config:
        from_attributes = True

class TimetableAIGenerateRequest(BaseModel):
    topics: List[str]
    daily_hours: float = 3.0
    start_day: int = 1 # 1=Monday
    goals: Optional[str] = None

# Chat Assistant
class ChatRequest(BaseModel):
    message: str
    context: Optional[str] = None

class ChatResponse(BaseModel):
    response: str
    suggested_actions: List[str] = []

# Settings
class SettingsResponse(BaseModel):
    gemini_api_key_configured: bool
    gemini_model: str
    database_url_configured: bool
    database_type: str

class SettingsUpdate(BaseModel):
    gemini_api_key: Optional[str] = None
    gemini_model: Optional[str] = None
