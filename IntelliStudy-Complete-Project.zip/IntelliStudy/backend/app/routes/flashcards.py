import json
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import FlashcardDeck, Note, UserProfile
from app.schemas import FlashcardDeckCreate, FlashcardDeckResponse
from app.services.gemini_service import gemini_service

router = APIRouter(prefix="/api/flashcards", tags=["Flashcards"])

def deck_to_response(d: FlashcardDeck) -> dict:
    cards = json.loads(d.cards) if d.cards else []
    return {
        "id": d.id,
        "title": d.title,
        "topic": d.topic,
        "note_id": d.note_id,
        "cards": cards,
        "created_at": d.created_at
    }

@router.get("", response_model=List[FlashcardDeckResponse])
def get_decks(db: Session = Depends(get_db)):
    decks = db.query(FlashcardDeck).order_by(FlashcardDeck.created_at.desc()).all()
    return [deck_to_response(d) for d in decks]

@router.get("/{deck_id}", response_model=FlashcardDeckResponse)
def get_deck(deck_id: int, db: Session = Depends(get_db)):
    deck = db.query(FlashcardDeck).filter(FlashcardDeck.id == deck_id).first()
    if not deck:
        raise HTTPException(status_code=404, detail="Flashcard deck not found")
    return deck_to_response(deck)

@router.post("/generate", response_model=FlashcardDeckResponse)
async def generate_flashcards(data: FlashcardDeckCreate, db: Session = Depends(get_db)):
    context_content = data.content or ""
    
    if data.note_id:
        note = db.query(Note).filter(Note.id == data.note_id).first()
        if note:
            context_content = f"{note.title}\n{note.summary}\n{note.content[:5000]}"
            if not data.topic:
                data.topic = note.title

    cards = await gemini_service.generate_flashcards(
        topic=data.topic,
        content=context_content,
        num_cards=data.num_cards
    )

    new_deck = FlashcardDeck(
        title=f"Deck: {data.topic}",
        topic=data.topic,
        note_id=data.note_id,
        cards=json.dumps(cards)
    )
    db.add(new_deck)

    # Award points to User Profile for creating flashcards (+30 points)
    user = db.query(UserProfile).first()
    if user:
        user.points += 30
        user.points_weekly_delta += 30

    db.commit()
    db.refresh(new_deck)

    return deck_to_response(new_deck)

@router.delete("/{deck_id}")
def delete_deck(deck_id: int, db: Session = Depends(get_db)):
    deck = db.query(FlashcardDeck).filter(FlashcardDeck.id == deck_id).first()
    if not deck:
        raise HTTPException(status_code=404, detail="Flashcard deck not found")
    db.delete(deck)
    db.commit()
    return {"message": "Flashcard deck deleted", "id": deck_id}
