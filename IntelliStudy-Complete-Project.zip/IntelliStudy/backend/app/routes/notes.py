import os
import json
import shutil
from typing import List
from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Note, UserProfile
from app.schemas import NoteResponse, NoteCreate
from app.services.pdf_service import extract_text_from_file
from app.services.gemini_service import gemini_service
from app.config import settings

router = APIRouter(prefix="/api/notes", tags=["Notes & Summaries"])

def note_to_response(n: Note) -> dict:
    takeaways = json.loads(n.key_takeaways) if n.key_takeaways else []
    concepts = json.loads(n.concepts) if n.concepts else []
    formulas = json.loads(n.formulas) if n.formulas else []
    return {
        "id": n.id,
        "title": n.title,
        "filename": n.filename,
        "file_type": n.file_type,
        "content": n.content,
        "summary": n.summary,
        "key_takeaways": takeaways,
        "concepts": concepts,
        "formulas": formulas,
        "created_at": n.created_at,
        "updated_at": n.updated_at
    }

@router.get("", response_model=List[NoteResponse])
def get_notes(db: Session = Depends(get_db)):
    notes = db.query(Note).order_by(Note.created_at.desc()).all()
    return [note_to_response(n) for n in notes]

@router.get("/{note_id}", response_model=NoteResponse)
def get_note(note_id: int, db: Session = Depends(get_db)):
    note = db.query(Note).filter(Note.id == note_id).first()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    return note_to_response(note)

@router.post("/upload")
async def upload_note(
    file: UploadFile = File(None),
    title: str = Form(None),
    text_content: str = Form(None),
    db: Session = Depends(get_db)
):
    saved_filename = None
    file_type = "text"
    extracted_text = ""

    if file and file.filename:
        saved_filename = file.filename
        ext = os.path.splitext(file.filename)[1].lower()
        file_type = ext.replace(".", "")
        dest_path = os.path.join(settings.upload_dir, file.filename)
        
        with open(dest_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        extracted_text = extract_text_from_file(dest_path)
        if not title:
            title = os.path.splitext(file.filename)[0].replace("_", " ").title()
    elif text_content:
        extracted_text = text_content
        if not title:
            title = "Study Notes: " + (text_content.split("\n")[0][:40] or "General")
    else:
        raise HTTPException(status_code=400, detail="Please upload a document file or provide text content.")

    if not extracted_text.strip():
        extracted_text = "No extractable text found in uploaded document."

    # Generate AI summary
    summary_data = await gemini_service.summarize_content(extracted_text, title=title)

    new_note = Note(
        title=title,
        filename=saved_filename,
        file_type=file_type,
        content=extracted_text,
        summary=summary_data.get("summary", ""),
        key_takeaways=json.dumps(summary_data.get("key_takeaways", [])),
        concepts=json.dumps(summary_data.get("concepts", [])),
        formulas=json.dumps(summary_data.get("formulas", []))
    )
    db.add(new_note)

    # Award points to User Profile for studying/uploading notes (+50 points)
    user = db.query(UserProfile).first()
    if user:
        user.points += 50
        user.points_weekly_delta += 50

    db.commit()
    db.refresh(new_note)

    return note_to_response(new_note)

@router.delete("/{note_id}")
def delete_note(note_id: int, db: Session = Depends(get_db)):
    note = db.query(Note).filter(Note.id == note_id).first()
    if not note:
        raise HTTPException(status_code=404, detail="Note not found")
    db.delete(note)
    db.commit()
    return {"message": "Note deleted successfully", "id": note_id}
