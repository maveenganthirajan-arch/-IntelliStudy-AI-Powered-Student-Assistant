import json
from typing import List, Optional
from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import TimetableEvent, UserProfile
from app.schemas import TimetableEventCreate, TimetableEventResponse, TimetableAIGenerateRequest
from app.services.gemini_service import gemini_service

router = APIRouter(prefix="/api/timetable", tags=["Timetable & Schedule"])

def event_to_response(e: TimetableEvent) -> dict:
    attendees = json.loads(e.attendees) if e.attendees else []
    return {
        "id": e.id,
        "title": e.title,
        "day_index": e.day_index,
        "start_time": e.start_time,
        "end_time": e.end_time,
        "description": e.description,
        "category": e.category,
        "attendees": attendees,
        "join_link": e.join_link,
        "is_completed": e.is_completed
    }

@router.get("", response_model=List[TimetableEventResponse])
def get_events(day: Optional[int] = Query(None), db: Session = Depends(get_db)):
    query = db.query(TimetableEvent)
    if day is not None:
        query = query.filter(TimetableEvent.day_index == day)
    events = query.order_by(TimetableEvent.start_time.asc()).all()
    return [event_to_response(e) for e in events]

@router.post("", response_model=TimetableEventResponse)
def create_event(data: TimetableEventCreate, db: Session = Depends(get_db)):
    new_event = TimetableEvent(
        title=data.title,
        day_index=data.day_index,
        start_time=data.start_time,
        end_time=data.end_time,
        description=data.description,
        category=data.category or "Lecture",
        attendees=json.dumps(data.attendees or ["/user_avatar.png"]),
        join_link=data.join_link or "#",
        is_completed=False
    )
    db.add(new_event)
    db.commit()
    db.refresh(new_event)
    return event_to_response(new_event)

@router.put("/{event_id}/toggle-complete")
def toggle_complete(event_id: int, db: Session = Depends(get_db)):
    event = db.query(TimetableEvent).filter(TimetableEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    
    event.is_completed = not event.is_completed
    
    # If completed, add study hours and points
    user = db.query(UserProfile).first()
    if user and event.is_completed:
        user.points += 40
        user.study_hours = round(user.study_hours + 1.5, 1)

    db.commit()
    db.refresh(event)
    return event_to_response(event)

@router.delete("/{event_id}")
def delete_event(event_id: int, db: Session = Depends(get_db)):
    event = db.query(TimetableEvent).filter(TimetableEvent.id == event_id).first()
    if not event:
        raise HTTPException(status_code=404, detail="Event not found")
    db.delete(event)
    db.commit()
    return {"message": "Event deleted", "id": event_id}

@router.post("/ai-generate", response_model=List[TimetableEventResponse])
async def ai_generate_timetable(req: TimetableAIGenerateRequest, db: Session = Depends(get_db)):
    generated_events = await gemini_service.generate_timetable_schedule(
        topics=req.topics,
        daily_hours=req.daily_hours,
        start_day=req.start_day,
        goals=req.goals
    )
    
    created_list = []
    for ev in generated_events:
        item = TimetableEvent(
            title=ev.get("title", "Study Session"),
            day_index=ev.get("day_index", 2),
            start_time=ev.get("start_time", "12:00"),
            end_time=ev.get("end_time", "13:45"),
            description=ev.get("description", ""),
            category=ev.get("category", "Lecture"),
            attendees=json.dumps(ev.get("attendees", ["/user_avatar.png"])),
            join_link=ev.get("join_link", "#"),
            is_completed=False
        )
        db.add(item)
        created_list.append(item)

    db.commit()
    for item in created_list:
        db.refresh(item)

    return [event_to_response(e) for e in created_list]
