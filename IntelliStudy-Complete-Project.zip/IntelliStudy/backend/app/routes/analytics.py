from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import UserProfile, LessonProgress, QuizAttempt, Note
from app.schemas import UserProfileSchema, LessonProgressItem

router = APIRouter(prefix="/api/analytics", tags=["Analytics & Progress"])

@router.get("/dashboard")
def get_dashboard_data(db: Session = Depends(get_db)):
    user = db.query(UserProfile).first()
    if not user:
        user = UserProfile(
            name="Anastasiia H.",
            course="AI Course",
            avatar_url="/user_avatar.png",
            points=836,
            max_points=1500,
            points_weekly_delta=290,
            study_hours=8.4,
            study_hours_delta_pct=-94,
            completed_lessons=62,
            total_lessons=105
        )
        db.add(user)
        db.commit()
        db.refresh(user)

    lessons = db.query(LessonProgress).all()
    if not lessons:
        lesson1 = LessonProgress(
            title="Key AI Concepts You Should Know",
            subtitle="You can be better!",
            progress_pct=75,
            last_accessed="5 min ago",
            category="Machine Learning"
        )
        lesson2 = LessonProgress(
            title="AI Basics: Terms, Models, and Data",
            subtitle="You're almost done!",
            progress_pct=94,
            last_accessed="2 h ago",
            category="Foundations"
        )
        db.add_all([lesson1, lesson2])
        db.commit()
        lessons = [lesson1, lesson2]

    # Calculate circular completion percentage
    rate = round((user.completed_lessons / user.total_lessons) * 100) if user.total_lessons > 0 else 59

    # Weekly hours breakdown (Mon - Sun)
    weekly_hours = [
        {"day": "Mon", "hours": 2.2, "target": 2.5},
        {"day": "Tue", "hours": 3.8, "target": 2.5},
        {"day": "Wed", "hours": 1.4, "target": 2.5},
        {"day": "Thu", "hours": 2.9, "target": 2.5},
        {"day": "Fri", "hours": 3.1, "target": 2.5},
        {"day": "Sat", "hours": 1.0, "target": 1.5},
        {"day": "Sun", "hours": 0.5, "target": 1.5},
    ]

    subject_mastery = [
        {"subject": "Neural Networks & Backprop", "score": 88, "color": "#8b5cf6"},
        {"subject": "Supervised Learning Models", "score": 94, "color": "#10b981"},
        {"subject": "Loss Functions & Optimization", "score": 76, "color": "#f59e0b"},
        {"subject": "Natural Language Transformers", "score": 82, "color": "#06b6d4"},
    ]

    return {
        "user": {
            "id": user.id,
            "name": user.name,
            "course": user.course,
            "avatar_url": user.avatar_url,
            "points": user.points,
            "max_points": user.max_points,
            "points_weekly_delta": user.points_weekly_delta,
            "study_hours": user.study_hours,
            "study_hours_delta_pct": user.study_hours_delta_pct,
            "completed_lessons": user.completed_lessons,
            "total_lessons": user.total_lessons,
            "completion_rate_pct": rate
        },
        "last_lessons": [
            {
                "id": l.id,
                "title": l.title,
                "subtitle": l.subtitle,
                "progress_pct": l.progress_pct,
                "last_accessed": l.last_accessed,
                "category": l.category
            } for l in lessons
        ],
        "weekly_hours": weekly_hours,
        "subject_mastery": subject_mastery,
        "study_streak_days": 14,
        "total_notes_count": db.query(Note).count()
    }

@router.post("/update-lesson-progress/{lesson_id}")
def update_progress(lesson_id: int, progress: int, db: Session = Depends(get_db)):
    lesson = db.query(LessonProgress).filter(LessonProgress.id == lesson_id).first()
    if not lesson:
        raise HTTPException(status_code=404, detail="Lesson not found")
    lesson.progress_pct = min(100, max(0, progress))
    if lesson.progress_pct == 100:
        lesson.subtitle = "Completed!"
        user = db.query(UserProfile).first()
        if user:
            user.completed_lessons = min(user.total_lessons, user.completed_lessons + 1)
            user.points += 100
    db.commit()
    return {"message": "Progress updated", "progress_pct": lesson.progress_pct}
