from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import ChatMessage
from app.schemas import ChatRequest, ChatResponse
from app.services.gemini_service import gemini_service

router = APIRouter(prefix="/api/assistant", tags=["AI Assistant"])

@router.post("/chat", response_model=ChatResponse)
async def chat_assistant(req: ChatRequest, db: Session = Depends(get_db)):
    # Record user message
    user_msg = ChatMessage(sender="user", message=req.message)
    db.add(user_msg)
    db.commit()

    # Call Gemini service
    ai_result = await gemini_service.chat(message=req.message, context=req.context or "")

    # Record assistant message
    asst_msg = ChatMessage(sender="assistant", message=ai_result.get("response", ""))
    db.add(asst_msg)
    db.commit()

    return {
        "response": ai_result.get("response", ""),
        "suggested_actions": ai_result.get("suggested_actions", [
            "Summarize my notes",
            "Generate Quiz on AI",
            "Plan my exam timetable"
        ])
    }

@router.get("/history")
def get_history(db: Session = Depends(get_db)):
    messages = db.query(ChatMessage).order_by(ChatMessage.timestamp.desc()).limit(20).all()
    return [
        {
            "id": m.id,
            "sender": m.sender,
            "message": m.message,
            "timestamp": m.timestamp
        }
        for m in reversed(messages)
    ]
