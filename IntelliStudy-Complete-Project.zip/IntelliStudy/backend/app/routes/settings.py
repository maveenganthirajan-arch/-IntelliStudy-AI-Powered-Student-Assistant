from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from app.database import get_db, db_url
from app.schemas import SettingsResponse, SettingsUpdate
from app.services.gemini_service import gemini_service
from app.config import settings

router = APIRouter(prefix="/api/settings", tags=["Settings"])

@router.get("", response_model=SettingsResponse)
def get_settings():
    is_postgres = "postgresql" in db_url.lower()
    return {
        "gemini_api_key_configured": bool(gemini_service.api_key),
        "gemini_model": gemini_service.model_name,
        "database_url_configured": bool(db_url),
        "database_type": "PostgreSQL" if is_postgres else "SQLite"
    }

@router.post("")
def update_settings(data: SettingsUpdate):
    if data.gemini_api_key is not None:
        gemini_service.update_api_key(data.gemini_api_key, data.gemini_model)
        settings.gemini_api_key = data.gemini_api_key
    if data.gemini_model:
        gemini_service.model_name = data.gemini_model
        settings.gemini_model = data.gemini_model

    return {
        "message": "Settings updated successfully",
        "gemini_api_key_configured": bool(gemini_service.api_key),
        "gemini_model": gemini_service.model_name
    }
