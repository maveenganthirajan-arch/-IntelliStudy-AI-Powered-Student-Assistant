import json
from typing import List
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app.database import get_db
from app.models import Quiz, QuizAttempt, Note, UserProfile
from app.schemas import QuizCreate, QuizResponse, QuizSubmitRequest, QuizSubmitResponse
from app.services.gemini_service import gemini_service

router = APIRouter(prefix="/api/quizzes", tags=["Quizzes"])

def quiz_to_response(q: Quiz) -> dict:
    questions = json.loads(q.questions) if q.questions else []
    return {
        "id": q.id,
        "title": q.title,
        "topic": q.topic,
        "note_id": q.note_id,
        "questions": questions,
        "total_questions": len(questions),
        "created_at": q.created_at
    }

@router.get("", response_model=List[QuizResponse])
def get_quizzes(db: Session = Depends(get_db)):
    quizzes = db.query(Quiz).order_by(Quiz.created_at.desc()).all()
    return [quiz_to_response(q) for q in quizzes]

@router.get("/{quiz_id}", response_model=QuizResponse)
def get_quiz(quiz_id: int, db: Session = Depends(get_db)):
    quiz = db.query(Quiz).filter(Quiz.id == quiz_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")
    return quiz_to_response(quiz)

@router.post("/generate", response_model=QuizResponse)
async def generate_quiz(data: QuizCreate, db: Session = Depends(get_db)):
    context_content = data.content or ""
    
    if data.note_id:
        note = db.query(Note).filter(Note.id == data.note_id).first()
        if note:
            context_content = f"{note.title}\n{note.summary}\n{note.content[:5000]}"
            if not data.topic:
                data.topic = note.title

    questions = await gemini_service.generate_quizzes(
        topic=data.topic,
        content=context_content,
        num_questions=data.num_questions
    )

    new_quiz = Quiz(
        title=f"Quiz: {data.topic}",
        topic=data.topic,
        note_id=data.note_id,
        questions=json.dumps(questions)
    )
    db.add(new_quiz)
    db.commit()
    db.refresh(new_quiz)

    return quiz_to_response(new_quiz)

@router.post("/{quiz_id}/submit", response_model=QuizSubmitResponse)
def submit_quiz(quiz_id: int, req: QuizSubmitRequest, db: Session = Depends(get_db)):
    quiz = db.query(Quiz).filter(Quiz.id == quiz_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")

    questions = json.loads(quiz.questions) if quiz.questions else []
    correct_count = 0
    results = []

    for i, q in enumerate(questions):
        user_ans = req.answers[i] if i < len(req.answers) else -1
        correct_ans = q.get("answer_index", 0)
        is_corr = (user_ans == correct_ans)
        if is_corr:
            correct_count += 1
        results.append({
            "question_id": q.get("id", i + 1),
            "question": q.get("question", ""),
            "options": q.get("options", []),
            "user_answer": user_ans,
            "correct_answer": correct_ans,
            "is_correct": is_corr,
            "explanation": q.get("explanation", "")
        })

    total = len(questions)
    pct = round((correct_count / total * 100), 1) if total > 0 else 0
    points_earned = correct_count * 25 # 25 points per correct answer

    # Record attempt
    attempt = QuizAttempt(
        quiz_id=quiz_id,
        score=correct_count,
        total_questions=total,
        percentage=pct
    )
    db.add(attempt)

    # Update User Profile points
    user = db.query(UserProfile).first()
    if user:
        user.points += points_earned
        user.points_weekly_delta += points_earned

    db.commit()

    return {
        "score": correct_count,
        "total": total,
        "percentage": pct,
        "points_earned": points_earned,
        "results": results
    }

@router.delete("/{quiz_id}")
def delete_quiz(quiz_id: int, db: Session = Depends(get_db)):
    quiz = db.query(Quiz).filter(Quiz.id == quiz_id).first()
    if not quiz:
        raise HTTPException(status_code=404, detail="Quiz not found")
    db.delete(quiz)
    db.commit()
    return {"message": "Quiz deleted", "id": quiz_id}
