import datetime
from sqlalchemy import Column, Integer, String, Text, Float, Boolean, DateTime, ForeignKey
from app.database import Base

class UserProfile(Base):
    __tablename__ = "user_profiles"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String(100), default="Anastasiia H.")
    course = Column(String(100), default="AI Course")
    avatar_url = Column(String(255), default="/user_avatar.png")
    points = Column(Integer, default=836)
    max_points = Column(Integer, default=1500)
    points_weekly_delta = Column(Integer, default=290)
    study_hours = Column(Float, default=8.4)
    study_hours_delta_pct = Column(Integer, default=-94)
    completed_lessons = Column(Integer, default=62)
    total_lessons = Column(Integer, default=105)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

class Note(Base):
    __tablename__ = "notes"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    filename = Column(String(255), nullable=True)
    file_type = Column(String(50), default="text")
    content = Column(Text, nullable=False)
    summary = Column(Text, nullable=True)
    key_takeaways = Column(Text, default="[]") # JSON string
    concepts = Column(Text, default="[]")      # JSON string
    formulas = Column(Text, default="[]")      # JSON string
    created_at = Column(DateTime, default=datetime.datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow, onupdate=datetime.datetime.utcnow)

class LessonProgress(Base):
    __tablename__ = "lesson_progress"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    subtitle = Column(String(255), default="Ready to study")
    progress_pct = Column(Integer, default=0)
    last_accessed = Column(String(50), default="Just now")
    category = Column(String(100), default="General")

class Quiz(Base):
    __tablename__ = "quizzes"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    topic = Column(String(255), nullable=False)
    note_id = Column(Integer, ForeignKey("notes.id", ondelete="SET NULL"), nullable=True)
    questions = Column(Text, nullable=False) # JSON array of {id, question, options, answer_index, explanation}
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class QuizAttempt(Base):
    __tablename__ = "quiz_attempts"

    id = Column(Integer, primary_key=True, index=True)
    quiz_id = Column(Integer, ForeignKey("quizzes.id", ondelete="CASCADE"))
    score = Column(Integer, nullable=False)
    total_questions = Column(Integer, nullable=False)
    percentage = Column(Float, nullable=False)
    completed_at = Column(DateTime, default=datetime.datetime.utcnow)

class FlashcardDeck(Base):
    __tablename__ = "flashcard_decks"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    topic = Column(String(255), nullable=False)
    note_id = Column(Integer, ForeignKey("notes.id", ondelete="SET NULL"), nullable=True)
    cards = Column(Text, nullable=False) # JSON array of {id, front, back, hint}
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class TimetableEvent(Base):
    __tablename__ = "timetable_events"

    id = Column(Integer, primary_key=True, index=True)
    title = Column(String(255), nullable=False)
    day_index = Column(Integer, default=2) # 0=Su, 1=Mo, 2=Tu, 3=We, 4=Th, 5=Fr, 6=Sa
    start_time = Column(String(10), nullable=False) # "12:00"
    end_time = Column(String(10), nullable=False)   # "13:45"
    description = Column(Text, nullable=True)
    category = Column(String(50), default="Lecture")
    attendees = Column(Text, default="[]") # JSON array of avatar URLs
    join_link = Column(String(255), default="#")
    is_completed = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow)

class ChatMessage(Base):
    __tablename__ = "chat_messages"

    id = Column(Integer, primary_key=True, index=True)
    sender = Column(String(20), nullable=False) # "user" or "assistant"
    message = Column(Text, nullable=False)
    timestamp = Column(DateTime, default=datetime.datetime.utcnow)
