import os
from pathlib import Path
from pydantic import BaseModel

BASE_DIR = Path(__file__).resolve().parent.parent

class Settings(BaseModel):
    app_name: str = "IntelliStudy — AI-Powered Student Assistant"
    app_version: str = "1.0.0"
    gemini_api_key: str = os.getenv("GEMINI_API_KEY", "")
    gemini_model: str = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
    database_url: str = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR / 'intellistudy.db'}")
    upload_dir: str = str(BASE_DIR / "uploads")
    cors_origins: list = ["*"]

settings = Settings()
os.makedirs(settings.upload_dir, exist_ok=True)
