# 🎓 IntelliStudy — AI-Powered Student Assistant

> **Best Overall Student Productivity Platform**  
> An intelligent study suite designed to summarize notes, generate quizzes, and plan study schedules with a modern dark-mode aesthetic inspired by futuristic UI design.

![IntelliStudy Reference Dashboard](frontend/public/reference_dashboard.png)

---

## 🌟 Key Features

### 1. 📄 Upload PDF Notes & Generate AI Summaries
- **Document Ingestion**: Upload PDF slides, textbooks, Markdown, or Word documents.
- **AI-Powered Analysis**: Gemini extracts executive summaries, 5–8 high-yield takeaways, core mechanisms, and formulas formatted with LaTeX.
- **One-Click Action**: Convert any summarized note directly into an interactive MCQ quiz or 3D flashcard deck.
- **Exporting**: Download structured notes in clean Markdown format with one click.

### 2. 🧠 AI-Generated MCQs & 3D Interactive Flashcards
- **Multiple Choice Quizzes**:
  - Automatically generates challenging, concept-testing questions with explanations.
  - Interactive quiz player with timer, live feedback, and celebratory confetti animations upon completion.
  - Automatically earns student points (+25 pts per correct answer) added to your Dashboard.
- **3D Flip Flashcards**:
  - Realistic 3D card flipping animations for active recall.
  - Front prompts with optional subtle hints; back reveals in-depth conceptual breakdown and equations.
  - Spaced repetition buttons (*"Need Review"* vs *"Got It!"*) to track retention.

### 3. 📅 Personalized Study Timetable & Calendar
- **Exact Layout from Reference Image**:
  - Horizontal day selector (`Su 04`, `Mo 05`, `Tu 06`, `We 07`, `Th 08`, `Fr 09`).
  - Vertical timeline from 12:00 to 17:00 with real-time `15:30` horizontal indicator.
  - Lecture cards (e.g. *How Machine Learning Works*, *Neural Networks Explained*) with classmate avatars and **"Join"** button.
- **AI Schedule Generator**: Enter topics and daily study goals to automatically schedule review intervals, labs, and quiz checkpoints.
- **Interactive Focus Room**: Clicking "Join" opens a Pomodoro focus timer with session objectives and a completion reward (+40 pts & +1.5h).

### 4. 📊 Progress Dashboard & Performance Charts
- **Overview Metrics**:
  - **Points**: `836/1500 Points` (↑ 290 this week).
  - **Hours**: `8.4 Hours` (↓ 94% from last week).
  - **Lessons**: `62/105 Lessons` with a circular gradient progress ring (`59%`).
  - **Last Lesson Tracker**: Progress bars and status for *"Key AI Concepts You Should Know"* (75%) and *"AI Basics: Terms, Models, and Data"* (94%).
- **Performance Analytics Tab**:
  - Weekly study hours distribution bar chart (actual vs daily target).
  - Subject competence progression across Machine Learning, Neural Networks, and Optimization.
  - Overall accuracy and scholar rank badge.

### 5. 🔮 AI Assistant & Glowing 3D Orb
- Floating, iridescent purple 3D orb with ambient pulsing glow.
- Quick tip shortcut pills (*"Summarize Note"*, *"Quiz Me"*, *"Study Tip"*).
- Interactive voice input simulation and chat drawer powered by Gemini AI.

---

## 🛠️ Technology Stack

| Layer | Technologies |
|---|---|
| **Frontend** | React 18, TypeScript, Tailwind CSS, Vite, Lucide Icons, Canvas-Confetti |
| **Backend** | Python 3.12, FastAPI, Uvicorn, SQLAlchemy, Pydantic, PyPDF |
| **Database** | PostgreSQL support (via `psycopg2`) + Automatic local SQLite fallback (`intellistudy.db`) |
| **AI Engine** | Google Gemini API (`gemini-1.5-flash`, `gemini-2.0-flash`) + Built-in offline AI fallback engine |

---

## 🚀 Quick Start Guide

### Option A: One-Click Run (Recommended)
Simply double-click:
```bat
run_app.bat
```
This runs the full-stack server on `http://127.0.0.1:8000/` and automatically opens your web browser.

---

### Option B: Development Mode (Hot Reload)
To run frontend and backend with hot-reload enabled:
```bat
run_dev.bat
```
- **Backend API**: `http://127.0.0.1:8000` (FastAPI Swagger docs at `/docs`)
- **Frontend App**: `http://localhost:3000` (Vite dev server)

---

### Option C: Manual Setup

#### 1. Backend Setup
```bash
cd backend
python -m pip install -r requirements.txt
python main.py
```
Backend will start on `http://127.0.0.1:8000`.

#### 2. Frontend Setup
```bash
cd frontend
npm install
npm run dev
```

---

## ⚙️ Configuration & Environment Variables

Create a `.env` file in the `backend/` folder (or use the built-in Settings UI):

```ini
# Google Gemini API Key (Get free from https://aistudio.google.com/)
GEMINI_API_KEY=your_gemini_api_key_here
GEMINI_MODEL=gemini-1.5-flash

# Database Connection (Defaults to local SQLite if omitted)
DATABASE_URL=sqlite:///./intellistudy.db

# To use PostgreSQL:
# DATABASE_URL=postgresql://postgres:password@localhost:5432/intellistudy
```

> **Note on Zero Configuration**: If `GEMINI_API_KEY` is not provided, the application runs seamlessly using its built-in smart AI fallback engine. You can enter or update your API key at any time directly through the in-app **Settings** modal!

---

## 📁 Project Architecture

```
IntelliStudy — AI-Powered Student Assistant/
├── backend/
│   ├── app/
│   │   ├── config.py             # App settings & env loading
│   │   ├── database.py           # SQLAlchemy setup (Postgres + SQLite fallback)
│   │   ├── models.py             # Database models
│   │   ├── schemas.py            # Pydantic validation schemas
│   │   ├── services/
│   │   │   ├── gemini_service.py # Gemini AI client & fallback engine
│   │   │   └── pdf_service.py    # PDF and text extraction
│   │   └── routes/
│   │       ├── analytics.py      # Dashboard stats & weekly charts
│   │       ├── assistant.py      # AI chatbot & suggested actions
│   │       ├── flashcards.py     # Flashcards CRUD & AI generator
│   │       ├── notes.py          # PDF notes upload & summarizer
│   │       ├── quizzes.py        # MCQs generation & submission
│   │       ├── settings.py       # Configuration management
│   │       └── timetable.py      # Timetable scheduler & calendar
│   ├── main.py                   # FastAPI server & static frontend serving
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── components/
│   │   │   ├── CalendarTimeline.tsx    # Left column: Day selector & timeline
│   │   │   ├── GreetingAndAssistant.tsx# Right column: Greeting & 3D AI Orb
│   │   │   ├── Header.tsx              # Top bar, search, notifications, profile
│   │   │   ├── HelpModal.tsx           # Quick user guide
│   │   │   ├── Sidebar.tsx             # Vertical navigation bar
│   │   │   ├── StatsLessons.tsx        # Middle column: Points, hours, lessons ring
│   │   │   └── StudySessionModal.tsx   # Pomodoro focus timer & room
│   │   ├── pages/
│   │   │   ├── NotesSummaries.tsx      # PDF upload & AI summary breakdown
│   │   │   ├── OverviewDashboard.tsx   # Reference image 3-column dashboard
│   │   │   ├── PerformanceCharts.tsx   # Study hours & subject mastery charts
│   │   │   ├── QuizzesFlashcards.tsx   # MCQ player & 3D flashcards
│   │   │   ├── SettingsModal.tsx       # Gemini API & Database config
│   │   │   └── TimetablePlanner.tsx    # Weekly timetable & AI scheduler
│   │   ├── services/
│   │   │   └── api.ts                  # Axios API client
│   │   ├── types/
│   │   │   └── index.ts                # TypeScript interfaces
│   │   ├── App.tsx                     # Main layout & router
│   │   └── index.css                   # Custom theme & 3D flip styling
│   ├── tailwind.config.js
│   ├── package.json
│   └── vite.config.ts
├── run_app.bat                   # 1-click launcher for production
├── run_dev.bat                   # 1-click launcher for development
└── test_server.py                # Automated integration test suite
```

---

## 🧪 Verification & Testing
Run the automated test suite anytime to verify backend integrity, database seeding, and frontend asset delivery:
```bash
python test_server.py
```
All endpoints will be validated automatically with detailed terminal logs.
