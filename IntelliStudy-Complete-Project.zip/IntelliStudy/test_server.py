import sys, time, threading, urllib.request, json
sys.path.insert(0, 'backend')
import uvicorn
from main import app

def run():
    uvicorn.run(app, host='127.0.0.1', port=8000, log_level='error')

t = threading.Thread(target=run, daemon=True)
t.start()
time.sleep(2.5)

print('[1/5] Testing Health Endpoint...')
with urllib.request.urlopen('http://127.0.0.1:8000/api/health') as r:
    print('Health response:', r.read().decode())

print('\n[2/5] Testing Dashboard Endpoint...')
with urllib.request.urlopen('http://127.0.0.1:8000/api/analytics/dashboard') as r:
    data = json.loads(r.read().decode())
    user = data['user']
    print(f"User: {user['name']} | Course: {user['course']}")
    print(f"Points: {user['points']}/{user['max_points']} (+{user['points_weekly_delta']} this week)")
    print(f"Hours: {user['study_hours']} | Lessons: {user['completed_lessons']}/{user['total_lessons']} ({user['completion_rate_pct']}%)")
    print("Last Lessons:")
    for l in data['last_lessons']:
        print(f" - {l['title']} [{l['progress_pct']}%] ({l['subtitle']})")

print('\n[3/5] Testing Timetable Endpoint...')
with urllib.request.urlopen('http://127.0.0.1:8000/api/timetable') as r:
    events = json.loads(r.read().decode())
    print(f"Total Scheduled Events: {len(events)}")
    for e in events:
        print(f" - [Day {e['day_index']}] {e['start_time']} - {e['end_time']}: {e['title']}")

print('\n[4/5] Testing Quizzes & Flashcards Endpoints...')
with urllib.request.urlopen('http://127.0.0.1:8000/api/quizzes') as r:
    quizzes = json.loads(r.read().decode())
    print(f"Quizzes available: {len(quizzes)} | First quiz: {quizzes[0]['title']}")

with urllib.request.urlopen('http://127.0.0.1:8000/api/flashcards') as r:
    decks = json.loads(r.read().decode())
    print(f"Flashcard Decks available: {len(decks)} | First deck: {decks[0]['title']}")

print('\n[5/5] Testing Production Frontend Root Delivery...')
with urllib.request.urlopen('http://127.0.0.1:8000/') as r:
    html = r.read().decode()
    print(f"Frontend HTML received: {len(html)} bytes | IntelliStudy in title: {'IntelliStudy' in html}")

print('\n>>> All integration tests PASSED successfully!')
